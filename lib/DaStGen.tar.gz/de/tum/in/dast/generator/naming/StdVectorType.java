// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.naming;

import de.tum.in.dast.generator.DastGenAST.Type;

public class StdVectorType extends Type {

	private String length;
	
	public StdVectorType(Type type, String length) {
		super(type);
		this.length = length;
	}

	public String getTypeString(boolean qualified) {
		return "std::vector<" + super.getTypeString(qualified) + ">";
	}
	
	@Override
	public Type getInnerType() {
		return super.getInnerType();
	}
	
	/**
	 * return true, if this type needs arguments for the constructor in the 
	 * initialization list of a class
	 */
	public boolean needsInitialization() {
		return true;
	}
	
	public String getInitialization(String fieldName) {
		return fieldName+"("+length+")";
	}
	
}
