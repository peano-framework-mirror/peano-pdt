// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.DastGenAST;

public class Typedef implements AbstractNode {

	private Type type;
	private String alias;

	public Typedef(Type type, String alias) {
		this.type = type;
		this.alias = alias;
	}
	
	public void applyVisitor(Visitor visitor) {
		visitor.process(this);
	}

	public Type getType() {
		return type;
	}
	
	public String getAlias() {
		return alias;
	}	
}
