// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.mapper;

import de.tum.in.dast.generator.DastGenAST.Size;
import de.tum.in.dast.generator.DastGenAST.Type;
import de.tum.in.dast.generator.memberSelection.Member;
import de.tum.in.dast.generator.memberSelection.PackedMember;
import de.tum.in.dast.util.DaStStringBuilder;

/**
 * Mapper for Packed-Members of non-array-type.
 */
public class PackedMapper extends SimpleMapper {

	public PackedMapper(PackedMember member, Type type) { 
		super(member, type);
	}
	
	@Override
	protected String getGetMethodBody(Member member) {
		DaStStringBuilder builder = new DaStStringBuilder();
		builder.incrementIndentLevel();
		
		// long mask = 2 ^ n - 1;
		// mask << member.getStart();
		// int tmp = mappedVar & mask;
		// tmp >> member.getStart();
		// return tmp; 
		
		String packedType = ((PackedMember)member).getBitFieldType();
		
		String bitfieldLength = getBitfieldLength().getStringRepresentation();
		builder.appendAndIndent(packedType+" mask = "+
				" (1 << ("+(bitfieldLength+")) - 1;"));
		builder.appendAndIndent("mask = " + ((PackedMember)member).getBitFieldCast() + "(mask << ("+((PackedMember)member).getStartIndex()+"));");
		
		builder.appendAndIndent(packedType+" tmp = " + ((PackedMember)member).getBitFieldCast() + "(" + 
				member.getMappedVariable() +" & mask);");
		
		builder.appendAndIndent("tmp = " + ((PackedMember)member).getBitFieldCast() + "(tmp >> ("+ ((PackedMember)member).getStartIndex() +"));");
		if (((PackedMember)member).getRangeStart() != 0) {
			builder.appendAndIndent("tmp = tmp + "+((PackedMember)member).getRangeStart()+";");
		}
		appendAssertionForGetter(builder, (PackedMember) member);
		builder.append("return (" + member.getType() + ") tmp;");

		return builder.toString();
	}
	
    @Override
	protected String getSetMethodBody(Member member) {
		PackedMember packedMember = (PackedMember) member;
		DaStStringBuilder builder = new DaStStringBuilder();
		builder.incrementIndentLevel();
		
		appendAssertion(builder, packedMember);
		
		// long mask = 2 ^ n - 1;
		// mask << member.getStart();
		// mappedVar = mappedVar & ~mask;
		// mappedVar = mappedVar |arg0 << member.getStart();
		
		String bitfieldLength = packedMember.getBitfieldLength().getStringRepresentation();
		builder.appendAndIndent(((PackedMember)member).getBitFieldType()+" mask = "+
				" (1 << ("+(bitfieldLength+")) - 1;"));
		String mappedVariable = packedMember.getMappedVariable();

		builder.appendAndIndent("mask = " + ((PackedMember)member).getBitFieldCast() + "(mask << ("+ packedMember.getStartIndex()+"));");
		builder.appendAndIndent(mappedVariable+" = " + ((PackedMember)member).getBitFieldCast() + "(" + mappedVariable + " & ~mask);");
		if (packedMember.getRangeStart() != 0) {
			builder.append(mappedVariable + " = " + ((PackedMember)member).getBitFieldCast() + "(" +	mappedVariable + " | ("+ 
//					translator.getArgumentName(member.getMemberName()) +" - " +
					((PackedMember)member).getBitFieldCast() + "(" + translator.getArgumentName(member.getMemberName()) +") - " +
					+ packedMember.getRangeStart() + ") << ("
					+ packedMember.getStartIndex() + "));");
		} else {
			builder.append(mappedVariable + " = " +	((PackedMember)member).getBitFieldCast() + "(" + mappedVariable + " | " + 
//					translator.getArgumentName(member.getMemberName()) + " << ("
					((PackedMember)member).getBitFieldCast() + "(" + translator.getArgumentName(member.getMemberName()) + ") << ("
					+ packedMember.getStartIndex() + "));");
		}
		
		return builder.toString();	
	}
	
	/**
	 * @return the length of the compressed member in bit
	 */
	public Size getBitfieldLength() {
		return type.getSize();
	}
	
	
	private void appendAssertion(DaStStringBuilder builder, PackedMember member) {
		if (!(member.getRangeStart() == member.getRangeEnd())) {
			builder.appendAndIndent(translator.getAssertion() + "((" 
					+ translator.getArgumentName(member.getMemberName()) + " >= " +
						member.getRangeStart()+" && "
					+ translator.getArgumentName(member.getMemberName()) + " <= " +
			member.getRangeEnd()+"));");
		}
	}
	
	private void appendAssertionForGetter(DaStStringBuilder builder, PackedMember member) {
		if (!(member.getRangeStart() == member.getRangeEnd())) {
			builder.appendAndIndent(translator.getAssertion() + "((" + 
					" tmp >= " + member.getRangeStart()+" && "
					+ " tmp <= " + member.getRangeEnd()+"));");
		}
	}
}
