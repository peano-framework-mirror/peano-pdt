// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.plugin;

import java.util.List;

import de.tum.in.dast.generator.DaStConfiguration;
import de.tum.in.dast.generator.memberSelection.Member;
import de.tum.in.dast.util.DaStStringBuilder;

//Dummy-Implementation of the CodePlugin, which simply does nothing
public class EmptyPlugin implements CodePlugin {

	public void generateDefinition(DaStConfiguration configuration,
			DaStStringBuilder stringBuilder, String qualifiedClassName,
			List<Member> virtualMembers, List<Member> internalMembers) {
	}

	public void generateImplementation(DaStConfiguration configuration,
			DaStStringBuilder stringBuilder, String qualifiedClassName,
			List<Member> virtualMembers, List<Member> internalMembers) {
	}

}
