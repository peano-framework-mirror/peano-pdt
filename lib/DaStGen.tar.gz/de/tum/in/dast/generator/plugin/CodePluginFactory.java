// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.plugin;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

/**
 * Factory class for NameTranslators.
 * Implementing the xxxclass of the Strategy-design pattern.
 *
 * @author Wolfgang Eckhardt, Tobias Weinzierl
 */
public class CodePluginFactory {
	/**
	 * The current translator which is to translate names according
	 * to certain naming conventions.
	 */
	private static ArrayList<CodePlugin> plugins = null;
	
	/**
	 * set the strategy, which will be used for nametranslation.
	 * 
	 * @param strategy name of the strategy to use.
	 * 			valid values are: 
	 */
	public static void setPlugins(Vector<String> pluginNames, boolean runQuiet) {
	  plugins = new ArrayList<CodePlugin>();
	  
		if (pluginNames.isEmpty()) {
			return;
		}
		
		for (int i = 0; i < pluginNames.size(); i++) {
			try {
				CodePlugin plugin = (CodePlugin) Class.forName(CodePluginFactory.class.getPackage().getName() 
						+ "."+pluginNames.get(i)).newInstance();
		    if (!runQuiet) {
          System.out.println("*** Added Plugin: " + pluginNames.get(i));
		    }
				plugins.add(plugin);
			} catch (InstantiationException e) {
				e.printStackTrace();
				System.err.println("Plugin " + pluginNames.get(i) +" not added! (Could not instantiate)");
			} catch (IllegalAccessException e) {
				e.printStackTrace();
				System.err.println("Plugin " + pluginNames.get(i) +" not added! (Illegal access)");
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
				System.err.println("Plugin " + pluginNames.get(i) +" not added! (Class not found)");
			}
		}
	}
	
	/**
	 * @return the nameTranslator depending on the strategy which 
	 * 				was set before. If no strategy was chosen before,
	 * 				an instance of SimpleNameTranslator will be returned.
	 */
	public static List<CodePlugin> getCodePlugins() {
		return plugins;
	}

}
