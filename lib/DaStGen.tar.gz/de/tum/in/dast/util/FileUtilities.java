// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PushbackReader;
import java.io.Reader;

import de.tum.in.dast.lexer.Lexer;
import de.tum.in.dast.lexer.LexerException;
import de.tum.in.dast.node.Start;
import de.tum.in.dast.parser.Parser;
import de.tum.in.dast.parser.ParserException;

/**
 * @author Wolfgang Eckhardt
 *
 * Utility-class for dealing with files.
 */
public class FileUtilities {

	/**
	 * parses a given file and creates the abstract syntax tree
	 * 
	 * @param path the path of the file to parse
	 * @return the abstract syntax tree, created from the file
	 * @throws IOException 
	 * @throws LexerException 
	 * @throws ParserException 
	 */
	public static Start parseFile(String path, boolean runQuiet) throws ParserException, LexerException, IOException {
    if (!runQuiet) {
      System.out.println("*** parsing file: "+path);
    }

		FileReader fileReader = new FileReader(path);

		return parseFile(fileReader);
	}
	
	public static Start parseFile(Reader reader) throws ParserException, LexerException, IOException {
		Lexer lexer = new Lexer (new PushbackReader(new BufferedReader(reader), 1024));
		Parser parser = new Parser(lexer);

		Start ast = parser.parse();
		return ast;
	}
	/**
	 * creates a Java.io.File object representing a directory. If the
	 * directory doesn't exist, it is created.
	 * 
	 * @param destination the path of the directory
	 * @return the newly created file
	 */
	public static File createDestinationDir(String destination, boolean runQuiet) {
		File destDir = new File(destination);
    if (!runQuiet) {
      System.out.println("Generating code to: "+destDir.getAbsolutePath());
    }
		if (!destDir.isDirectory()) {
			if (destDir.exists()) {
				System.err.println("Error: The destination directory is a file!");
				return null; //TODO: Better throw exception?!
			}
			if (!destDir.mkdirs()) {
				System.err.println("Error: Could not create destination directory!");
				return null; //TODO: Better throw exception?!
			}
		}
		return destDir;
	}
	
	/**
	 * writes a String to a file. Makes sure, that the String is terminated
	 * by a newLine.
	 * 
	 * @param fileName the name of the file that should be written
	 * @param content the content that should be written to the file
	 */
	public static void writeFile(String fileName, String content, boolean runQuiet) {
    if (!runQuiet) {
		  System.out.println("writing file: "+fileName);
    }
		try {	
			FileWriter writer = new FileWriter(fileName);
			writer.write(content);
			writer.write("\n");
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
