// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import de.tum.in.dast.generator.DastGenAST.Class;
import de.tum.in.dast.generator.DastGenAST.DaStGenASTBuilder;
import de.tum.in.dast.generator.DastGenAST.Enumeration;
import de.tum.in.dast.generator.DastGenAST.Struct;
import de.tum.in.dast.generator.DastGenAST.Typedef;
import de.tum.in.dast.generator.memberSelection.Member;
import de.tum.in.dast.generator.naming.NameTranslator;
import de.tum.in.dast.generator.naming.NameTranslatorFactory;
import de.tum.in.dast.util.DaStStringBuilder;

public class MethodGenerator {
	
	private DaStStringBuilder header;
	private DaStStringBuilder implementation; 
	private String className;
	
	private NameTranslator naming = NameTranslatorFactory.getNameTranslator();
	
	public MethodGenerator(DaStStringBuilder header, DaStStringBuilder implementation ) {
		this.header = header;
		this.implementation = implementation;
	}
	
	public void generateMethods(Class classObject) {
		if ("".equals(classObject.getNamespace())) {
			this.className = classObject.getClassname();
		} else {
			this.className = classObject.getNamespace()+ "::" + classObject.getClassname();
		}
		
		ArrayList<Member> assertionMembers = new ArrayList<Member>();
		assertionMembers.addAll(classObject.getInternalMembers());
		assertionMembers.addAll(classObject.getStruct().getInternalMembers());
		
		// generate constructors
		generateConstructors(classObject.getNamespace(), classObject.getClassname(), 
				classObject.getVirtualMembers(), classObject.getStruct().getVirtualMembers(), assertionMembers, true);
		
		generateDestructor(classObject.getClassname());
		
		// generate methods related to members
		for (Member m: classObject.getVirtualMembers()) {
		  if (DaStConfiguration.manuallyInline)  {
	      m.generateMethodImplementations(header);
		  }
		  else {
        m.generateMethodSignatures(header);
	      m.generateMethodImplementations(implementation);		    
		  }
		}
		
		// generate Enum methods
		for (Enumeration e: classObject.getEnumerations().values()) {
			generateEnumerationMethodSignatures(e, header);
			generateEnumerationMethodImplementations(implementation, e);
		}
		
		for (Typedef typedef: classObject.getEnumTypedefs()) {
			Enumeration e = (Enumeration) typedef.getType();
			generateEnumerationMethodSignatures(e, header);
			generateEnumerationMethodDelegates(implementation, e);
		}
		
		generateToStringMethod();
		generateToStringStreamMethod(classObject.getVirtualMembers());
		generateGetPersistentRecordsMethod();
		generateConversionMethods(classObject);		
	}


	public void generateMethods(Struct struct) {
		generateConstructors(struct.getNamespace(), struct.getStructName(), struct.getVirtualMembers(), 
				new ArrayList<Member>(), struct.getInternalMembers(), false);
		
		for (Member m: struct.getVirtualMembers()) {		
      if (DaStConfiguration.manuallyInline) {
        m.generateGetterSetterMethods(header);
      }
      else {
        m.generateGetterSetterSignatures(header);
        m.generateGetterSetterMethods(implementation);
      }
		}
	}
	
	public void generateConstructors(String namespace, String simpleClassName, 
			ArrayList<Member> members, ArrayList<Member> persistentMembers, ArrayList<Member> assertionMembers, 
			boolean hasPersistentRecords) {
		
		ConstructorGenerator constructor = new ConstructorGenerator(namespace, simpleClassName, 
				members, assertionMembers);
		constructor.generateConstructors(implementation, header, hasPersistentRecords);
	}
	
	
	private void generateDestructor(String simpleClassname) {
		writeMethodComment(header);
		
    if (naming.isDestructorVirtual()) {
      header.appendAndIndent("virtual ~"+simpleClassname+"();");
    }
    else {
      header.appendAndIndent("~"+simpleClassname+"();");
    }
		header.indent();
		
		implementation.append(className+"::~"+simpleClassname+"() { }");
		implementation.indent(2);
	}
	

	/*********** ToString-Methods ***************/
	
	private void generateToStringMethod() {
		writeMethodComment(header);
		header.appendAndIndent("std::string toString() const;");
		header.indent();
		
		implementation.indent(2);
		implementation.append("std::string "+className+"::toString() const {");
		implementation.incrementAndIndent();
		implementation.appendAndIndent("std::ostringstream stringstr;");
		implementation.appendAndIndent("toString(stringstr);");
		implementation.append("return stringstr.str();");
		implementation.decrementAndIndent();
		implementation.appendAndIndent("}");
	}
	
	
	private void generateToStringStreamMethod(ArrayList<Member> members) {
		writeMethodComment(header);
		header.appendAndIndent("void toString(std::ostream& out) const;");
		header.indent();
		
		implementation.indent();
		implementation.append("void "+className+"::toString (std::ostream& out) const {");
		implementation.incrementAndIndent();
		implementation.appendAndIndent("out << \"(\"; ");
		Iterator<Member> iterator = members.iterator();
		while (iterator.hasNext()) {
			String partialToString = iterator.next().getToString(); 
			implementation.appendAndIndent(partialToString);
			if (iterator.hasNext()) {
				implementation.appendAndIndent("out << \",\";");
			}
		}
		implementation.append("out <<  \")\";");
		implementation.decrementAndIndent();
		
		implementation.append("}");
		implementation.indent(2);
	}
	
	
	/************* GetPersistentRecords ************/
	private void generateGetPersistentRecordsMethod() {
		header.indent();
		header.appendAndIndent(naming.getPersistentRecords() + " " + 
				naming.getGetter(DaStGenASTBuilder.FIELD_PERSISTENT_RECORDS) + "() const;");
		
		implementation.indent();
		implementation.append(className + "::"  + naming.getPersistentRecords() + " " + 
				className + "::"  + naming.getGetter(DaStGenASTBuilder.FIELD_PERSISTENT_RECORDS) + "() const {");
		implementation.incrementAndIndent();
		implementation.append("return " + naming.getAttributeName(DaStGenASTBuilder.FIELD_PERSISTENT_RECORDS) + ";");
		implementation.decrementAndIndent();
		implementation.appendAndIndent("}");
		implementation.indent();
	}
	
	/************* Enumeration Methods *************/

	private void generateEnumerationMethodDelegates(
			DaStStringBuilder implementation, Enumeration e) {
		implementation.append(getEnumerationToStringSignature(e, true) + " {");
		implementation.incrementAndIndent();
		//className + "::
		implementation.append("return "+ e.getQualification()+ "::toString(param);");
		implementation.decrementAndIndent();
		implementation.appendAndIndent("}");
		
		implementation.indent();
		implementation.append(getGetEnumerationMappingSignature(e, true) + " {");
		implementation.incrementAndIndent();
		implementation.append("return "+ e.getQualification()+"::get" + e.getTypeString(false) + "Mapping();");
		implementation.decrementAndIndent();
		implementation.append("}");
		implementation.indent(2);
	}
	
	
	private void generateEnumerationMethodImplementations(DaStStringBuilder builder, Enumeration enumeration){
    	
    	builder.append(getEnumerationToStringSignature(enumeration, true) + " {");
		builder.incrementAndIndent();
		builder.append("switch (param) {");
		builder.incrementAndIndent();

		Iterator<String> iterator = enumeration.getValues().iterator();
		while (iterator.hasNext()) {
			String value = iterator.next();
			builder.append("case "+value+": return \""+value+"\";");
			if (iterator.hasNext()) {
				builder.indent();
			}
		}
		builder.decrementAndIndent();
		builder.appendAndIndent("}");
		builder.append("return \"undefined\";");
		builder.decrementAndIndent();
		builder.appendAndIndent("}");
		
		builder.indent();
		builder.append(getGetEnumerationMappingSignature(enumeration, true) + " {");
		builder.incrementAndIndent();
		builder.append("return \"" + enumeration.getTypeString(false) + "(");

		iterator = enumeration.getValues().iterator();
		int counter = 0;
		while (iterator.hasNext()) {
			String value = iterator.next();
			builder.append(value+"="+counter);
			if (iterator.hasNext()) {
				builder.append(",");
			} else {
				builder.append(")\";");
			}
			counter++;
		}
		
		builder.decrementAndIndent();
		builder.append("}");
		builder.indent();
    }
    
    private void generateEnumerationMethodSignatures(Enumeration enumeration, DaStStringBuilder builder) {
		writeMethodComment(builder);
    	builder.appendAndIndent(getEnumerationToStringSignature(enumeration, false) + ";");
		builder.indent();
		writeMethodComment(builder);
		builder.appendAndIndent(getGetEnumerationMappingSignature(enumeration, false) + ";");
		builder.indent();
    }
    
    private String getEnumerationToStringSignature(Enumeration enumeration, boolean qualified) {
    	if (qualified) {
    		return "std::string " + className + "::toString(const " + enumeration.getTypeString(false) + "& param)";
    	} else {
    		return "static std::string toString(const " + enumeration.getTypeString(false) + "& param)";	
    	}
    }
    
    private String getGetEnumerationMappingSignature(Enumeration enumeration, boolean qualified) {
    	if (qualified) {
    		return "std::string " + className+ "::get" + enumeration.getTypeString(false) + "Mapping()";
    	} else {
    		return "static std::string get" + enumeration.getTypeString(false) + "Mapping()";
    	}
    }
    
    
    /*********** Conversion Methods  ******/
    
    private void generateConversionMethods(Class classObject) {
    	String namespace = classObject.getNamespace();
    	if (!"".equals(namespace)) {
    		namespace += "::";
    	}

    	/** header method declaration **/
    	writeMethodComment(header);
		header.appendAndIndent(classObject.getDualClassname() + " convert() const;");
		header.indent();
		
		/** method implementations **/
		implementation.append(namespace + classObject.getDualClassname() + " " +
				namespace + classObject.getClassname() + "::convert() const");
		Collection<Member> members = classObject.getVirtualMembers();
		
		generateConversionMethodConstructorCall(classObject.getDualClassname(), members);
    }
    
    private void generateConversionMethodConstructorCall(String classname, Collection<Member> members) {
    	implementation.append("{");
    	implementation.incrementAndIndent();
    	implementation.append("return " + classname + "(");
		implementation.incrementAndIndent();

		Iterator<Member> it = members.iterator();
		while (it.hasNext()) {
			Member m = it.next();
			String getter = "";

			getter += naming.getGetter(m.getMemberName()); 
			if (it.hasNext()) {
				implementation.appendAndIndent(getter + "(),");
			} else {
				implementation.append(getter + "()");
			}
		}
		implementation.decrementAndIndent();
		implementation.append(");");
		implementation.decrementAndIndent();
		implementation.appendAndIndent("}");
		implementation.indent();
    }

	public static void writeMethodComment(DaStStringBuilder builder) {
		builder.appendAndIndent("/**");
		builder.appendAndIndent(" * Generated");
		builder.appendAndIndent(" */");
	}
	
}
