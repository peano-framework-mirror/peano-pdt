// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.util;

import java.io.File;
import java.io.IOException;
import java.util.LinkedList;
import java.util.Vector;

import de.tum.in.dast.analysis.DepthFirstAdapter;
import de.tum.in.dast.lexer.LexerException;
import de.tum.in.dast.node.AExtendsStatement;
import de.tum.in.dast.node.Start;
import de.tum.in.dast.parser.ParserException;

/**
 * This class takes the path to a dastGen datastructure definition file, 
 * and recursivly reads the file as well as files referenced via the 
 * "Extends:"-directive.
 * 
 * @author Wolfgang Eckhardt
 * 
 */
public class TreeReader extends DepthFirstAdapter {
	
	// the absolute path of the file, referencing the first file to read
	private String sourceFile = null;

	// the absolute file of the directory, where the first definition file
	// is located. Needed to construct the path of referenced files.
	private File directory = null;

	// the list of trees read, which will be returned after by readTrees()
	private LinkedList<Start> trees = new LinkedList<Start>();
	
	// list of files read.
	private LinkedList<String> filesRead = new LinkedList<String>();
	
	// exception, we caught during parsing.
	private Exception caughtException = null;
	
	private Vector<String> searchPaths;
	
	private boolean runQuiet;
	
	/**
	 * @param source the path (absolute or relative) to the file which should
	 * 					be parsed.
	 */
	public TreeReader(String source, Vector<String> searchPaths, boolean runQuiet) {
		File sourceFile = new File(source);
		// we have to operate on the absolute file. Otherwise it might
		// not have a parent (see documentation of java.io.File)
		directory        = sourceFile.getAbsoluteFile().getParentFile();
		this.sourceFile  = sourceFile.getAbsolutePath();
		this.searchPaths = searchPaths;
		this.runQuiet    = runQuiet;
	}
	
	/**
	 * starts parsing the file which was specified as parameter in the constructor
	 * 
	 * @return a LinkedList containing all the syntax trees, constructed from the 
	 * 			files read. The order of the trees corresponds to the reverse 
	 * 			order the files	are parsed. 
	 * 			I.e., if A extends B extends C, and C is specified as argument of
	 * 			the constructor, the order in the list is A, B, C;
	 * 			
	 * @throws Exception if a ParserException, a LexerExeption of an IOException 
	 * 			occurred
	 */
	public LinkedList<Start> readTrees() throws Exception {
		readTrees(sourceFile);
		if (caughtException != null) {
      System.err.print( "*** Search pathes: ." );
		  for (String p: searchPaths) {
		    System.err.print( ", " + p);
		  }
      System.err.println( "" );
			throw caughtException;
		}
		return trees;
	}
	
	private void readTrees(String file) throws ParserException, LexerException, IOException {
		if (filesRead.contains(file)) {
			System.err.println("XXX");
			System.err.println("XXX Warning: File "+file+" already processed!");
			System.err.println("XXX");
			return;
		}
		
		Start tree = FileUtilities.parseFile(file, runQuiet);
		filesRead.add(file);
		
		if (tree == null) {
			// in case an exception occurred, 
			//the tree returned is null
			return;
		}
		
//		trees.push(tree);
		trees.addFirst(tree);
		tree.apply(this);
	}

	private void readFile( String path ) {
    try {
      readTrees(path);
    } catch (Exception e) {
      caughtException = e;
    }
	}
	
	@Override
	public void inAExtendsStatement(AExtendsStatement node) {
		String fileName = node.getExtendname().getText();

		String simplesFileName = directory.getAbsolutePath() + File.separator + fileName;
		LinkedList<String> pathes = new LinkedList<String>();		
		pathes.add(fileName);
		pathes.add(simplesFileName);

		for (String p: searchPaths) {
			pathes.add( p + fileName );
			pathes.add( p + File.separator + fileName );
			pathes.add( directory.getAbsolutePath() + File.separator + p + fileName );
			pathes.add( directory.getAbsolutePath() + File.separator + p + File.separator + fileName );
		}

		for (String entry: pathes) {
			java.io.File file = new java.io.File(entry);
			if ( file.exists() ) {
				readFile( entry );
				return;
			}
		}
		System.err.println( "Error: File " + fileName + " not found" );
		System.err.println( pathes.size() + " pathes tried" );
		System.err.println( "Search pathes: " + pathes.toString() );
		System.exit(-1);
	}
}
