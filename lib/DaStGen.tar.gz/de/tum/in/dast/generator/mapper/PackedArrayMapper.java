// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.mapper;

import de.tum.in.dast.generator.DastGenAST.Size;
import de.tum.in.dast.generator.DastGenAST.Type;
import de.tum.in.dast.generator.memberSelection.Member;
import de.tum.in.dast.generator.memberSelection.PackedMember;
import de.tum.in.dast.util.DaStStringBuilder;

public class PackedArrayMapper extends ArrayMapper {

	public PackedArrayMapper(Member member, Type type) {
		super(member, type);
	}

	@Override
	protected void getGetMethodBody(DaStStringBuilder builder) {
		String packedType = ((PackedMember)member).getBitFieldType();
		
		int bitfieldLength = getSingleElementLength().getSize();
		builder.appendAndIndent(packedType+" mask = "+
				((long) (Math.pow(2, bitfieldLength) - 1 ) + ";"));
		builder.appendAndIndent("mask = mask << ("+((PackedMember)member).getStartIndex()+");");
		
		String resultName = "result";
		if (type.needsInitialization()) {
			resultName = type.getInitialization(resultName);
		}
		builder.appendAndIndent(type.getTypeString(false) + " " + resultName + ";");
		builder.appendAndIndent(packedType+" tmp;");
		builder.indent();
		builder.append("for (int i = 0; i < "+member.getArraySize().getStringRepresentation()+"; i++) {");
		builder.incrementIndentLevel(getClass().getName());
		builder.indent();
		
		builder.appendAndIndent("tmp = " + member.getMappedVariable() +" & mask;");
		builder.appendAndIndent("tmp = tmp >> ("+ ((PackedMember)member).getStartIndex() +
				" + i * "+getSingleElementLength().getStringRepresentation()+");");
		if (((PackedMember)member).getRangeStart() != 0) {
			builder.appendAndIndent("tmp = tmp + "+((PackedMember)member).getRangeStart()+";");
		}
		
		builder.appendAndIndent("result[i] = ("+member.getType()+") tmp;");
		builder.append("mask = mask << " + getSingleElementLength().getStringRepresentation() + ";");
		builder.decrementAndIndent(getClass().getName());
		builder.appendAndIndent("}");
		
		appendAssertionForGetter(builder, (PackedMember) member, false);
		
		builder.append("return result;");
	}

	
	@Override
	protected void getSetMethodBody(DaStStringBuilder builder) {
		PackedMember packedMember = (PackedMember) member;
		builder.indent();
		appendAssertion(builder, packedMember, false);
		
		String mappedVariable = packedMember.getMappedVariable();
		int bitfieldLength = getSingleElementLength().getSize();

		builder.append("for (int i = 0; i < " + member.getArraySize().getStringRepresentation() + "; i++) {");
		builder.incrementAndIndent(getClass().getName());

		builder.appendAndIndent(((PackedMember)member).getBitFieldType() +" mask = "+ ((long) (Math.pow(2, bitfieldLength) - 1 ) + ";"));

		builder.appendAndIndent("mask = mask << ("+ packedMember.getStartIndex() + " + i * "+ getSingleElementLength().getStringRepresentation()+" );");
		builder.appendAndIndent(mappedVariable+" = " + mappedVariable + " & ~mask;");
		// until here, we deleted the whole part of the bitfield, occupied by the array

		builder.appendAndIndent( ((PackedMember)member).getBitFieldType() +" tmp = " + ((PackedMember)member).getBitFieldCast() + "(" + translator.getArgumentName(member.getMemberName()) + "[i]);" );

		if (packedMember.getRangeStart() != 0) {
			builder.append(mappedVariable + " = " +	mappedVariable + " | ( tmp - " +
					+ packedMember.getRangeStart() + ") << ("
					+ packedMember.getStartIndex() + " + i * "+ getSingleElementLength().getStringRepresentation()+");");
		} else {
			builder.append(mappedVariable + " = " + mappedVariable + " | ( tmp << ("
					+ packedMember.getStartIndex() + " + i * "+ getSingleElementLength().getStringRepresentation() + "));");
		}
		builder.decrementAndIndent(getClass().getName());
		builder.append("}");
	}
	
	@Override
	protected void getSetElementMethodBody(DaStStringBuilder builder) {
		PackedMember packedMember = (PackedMember) member;

		builder.indent();
		writeElementAccessAssertions(builder);
		
		appendAssertion(builder, packedMember, true);
		
		int bitfieldLength = getSingleElementLength().getSize();
		builder.appendAndIndent(((PackedMember)member).getBitFieldType()+" mask = "+
				((long) (Math.pow(2, bitfieldLength) - 1 ) + ";"));
		String mappedVariable = packedMember.getMappedVariable();

		builder.appendAndIndent("mask = mask << ("+ packedMember.getStartIndex()
				+ " + elementIndex * " + getSingleElementLength().getStringRepresentation() + ");");
		builder.appendAndIndent(mappedVariable+" = " + mappedVariable + " & ~mask;");
		builder.appendAndIndent(((PackedMember)member).getBitFieldType()+" tmp = " + ((PackedMember)member).getBitFieldCast() + "(" + translator.getArgumentName(member.getMemberName()) + ");" );
		if (packedMember.getRangeStart() != 0) {
			builder.append(mappedVariable + " = " +	mappedVariable + " | ( tmp - " +
					+ packedMember.getRangeStart() + ") << ("
					+ packedMember.getStartIndex() + " + elementIndex * "+ getSingleElementLength().getStringRepresentation()+");");
		} else {
			builder.append(mappedVariable + " = " + mappedVariable + " | ( tmp << ("
					+ packedMember.getStartIndex() +" + elementIndex * "+ getSingleElementLength().getStringRepresentation() +"));");
		}
	}
	
	@Override
	protected void getGetElementMethodBody(DaStStringBuilder builder) {
		builder.indent();		
		writeElementAccessAssertions(builder);
		
		String packedType = ((PackedMember)member).getBitFieldType();
		
		int bitfieldLength = getSingleElementLength().getSize();
		builder.appendAndIndent(packedType+" mask = "+
				((long) (Math.pow(2, bitfieldLength) - 1 ) + ";"));
		builder.appendAndIndent("mask = mask << ("+((PackedMember)member).getStartIndex() + " + elementIndex * " + bitfieldLength + ");");
		
		builder.appendAndIndent(packedType+" tmp = " + member.getMappedVariable() +" & mask;");
		
		builder.appendAndIndent("tmp = tmp >> ("+ ((PackedMember)member).getStartIndex() + " + elementIndex * " + bitfieldLength + ");");
		
		if (((PackedMember)member).getRangeStart() != 0) {
			builder.appendAndIndent("tmp = tmp + "+((PackedMember)member).getRangeStart()+";");
		}
		appendAssertionForGetter(builder, (PackedMember)member, true);
		builder.append("return (" + member.getType() + ") tmp;");
	}
	
	/**
	 * @return the length of a single element of the array
	 */
	protected Size getSingleElementLength() {
		return type.getSize();
	}
	
	/**
	 * @return the length of the compressed member in bit, i.e. the
	 * 			bitlength of a single element * arrayLength
	 * 
	 * @todo this method is buggy: somehow we return a size object which
	 *       has the ToString() representation of another size object!  
	 */
	public Size getBitfieldLength() {
		Size result;
		Size arraySize = member.getArraySize();
		Size singleElementSize = getSingleElementLength();
		
		if (arraySize.getSize() > 0 && singleElementSize.getSize() > 0) {
			result = new Size (arraySize.getSize() * singleElementSize.getSize());
		} else {
			String arrayLength = member.getArraySize().getStringRepresentation();
			result = new Size(getSingleElementLength() + " * " + arrayLength);
		}
		
		return result;
	}
	
	private void appendAssertion(DaStStringBuilder builder, PackedMember member, boolean arrayElement) {
		if (!(member.getRangeStart() == member.getRangeEnd())) {
			if (arrayElement) {
			builder.appendAndIndent(translator.getAssertion() + "((" 
					+ translator.getArgumentName(member.getMemberName()) + " >= " +
						member.getRangeStart()+" && "
					+ translator.getArgumentName(member.getMemberName()) + " <= " +
			member.getRangeEnd()+"));");
			} else {
				builder.append("for (int i = 0; i < "+member.getArraySize().getStringRepresentation()+"; i++) {");
				builder.incrementAndIndent(getClass().getName());
				
				builder.append(translator.getAssertion() + "((" 
						+ translator.getArgumentName(member.getMemberName()) + "[i] >= " +
							member.getRangeStart()+" && "
						+ translator.getArgumentName(member.getMemberName()) + "[i] <= " +
				member.getRangeEnd()+"));");
				
				builder.decrementAndIndent(getClass().getName());
				builder.appendAndIndent("}");
			}
		}
	}
	
	private void appendAssertionForGetter(DaStStringBuilder builder, PackedMember member, boolean arrayElement) {
		if (!(member.getRangeStart() == member.getRangeEnd())) {
			if (arrayElement) {
			builder.appendAndIndent(translator.getAssertion() + "(" 
					+ translator.getArgumentName("(tmp >= " + member.getRangeStart()
					+") && (tmp <= " +member.getRangeEnd()+"));"));
			} else {
				builder.append("for (int i = 0; i < "+member.getArraySize().getStringRepresentation()+"; i++) {");
				builder.incrementAndIndent(getClass().getName());
				
				builder.append(translator.getAssertion() + "((" 
						+ "result[i] >= " +	member.getRangeStart()+" && "
						+ "result[i] <= " +	member.getRangeEnd()+"));");
				
				builder.decrementAndIndent(getClass().getName());
				builder.appendAndIndent("}");
			}
		}
	}
}
