// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.memberSelection;

import java.util.ArrayList;

import de.tum.in.dast.generator.DastGenAST.Size;
import de.tum.in.dast.generator.naming.NameTranslatorFactory;
import de.tum.in.dast.util.DaStStringBuilder;
import de.tum.in.dast.util.RangeCalculator;

/**
 * This class represents a bitfield.
 * Thus, it collects the member variables, which are packed in it,
 * creates the corresponding definitions and methods or delegates
 * to its members, if appropriate.
 * 
 * @author Wolfgang Eckhardt
 *
 */
public class BitfieldMember extends Member {

	// the list containing all the members which are packed to this bitfield
	private ArrayList<PackedMember> members = new ArrayList<PackedMember>();
	
	private Size size;
	
	public BitfieldMember(String memberName, String type) {
		super(memberName, type);
		size = new Size(0);
	}
	
	public Size getBitfieldSize() {
		return size;
	}
	
	public void setBitfieldSize(Size newSize) {
		size = newSize;
	}
	
	public Member clone() {
		throw new RuntimeException("Method clone() not implemented for class: " + this.getClass());
	}
	
	public void addMember(PackedMember member) {
		if (member.isParallel()) {
			this.setParallel(true);
		}
		
		// check that we add only members of same persistence
		if (members.size() > 0 && this.persistent && !member.isPersistent())
		{
			throw new RuntimeException("persistent BitfieldMember "+this.getMemberName()
					+" can't hold discard member!");
		}
		
		if (members.size() > 0 && !this.persistent && member.isPersistent())
		{
			throw new RuntimeException("discard BitfieldMember "+this.getMemberName()
					+" can't hold persistent member!");
		}
		
		if (member.isPersistent())
		{
			this.setPersistent(member.isPersistent());
		}
		
		members.add(member);
	}
	
	@Override
	public void writeDeclaration(DaStStringBuilder builder, boolean currentClassIsPacked) {
		builder.indent();
		builder.appendAndIndent("/** mapping of records:");
		builder.appendAndIndent("|| Member \t|| startbit \t|| length");
		for (PackedMember member: members) {
			if (member.getBitfieldLength() == null 
					|| "0".equals(member.getBitfieldLength().getStringRepresentation())) { // TODO: what to do with packed records of length "0"?
				throw new RuntimeException("Error in declaring member: "+member.getMemberName() +
						" This member should be packed, but its calculated length is '0'");// in this case, there must be an error
			}
		
			String fieldSize = RangeCalculator.getTotalBitSize(member);
			builder.appendAndIndent(" |  "+member.getMemberName()+"\t| startbit " +
					fieldSize +"\t| #bits " + member.getBitfieldLength().getStringRepresentation());
		}
		builder.appendAndIndent(" */");	
		mapper.writeDeclaration(builder, currentClassIsPacked);
		builder.indent();
	}

	
	@Override
	public void writeConstructorAsserts(DaStStringBuilder builder) {
		builder.append("if ((" + RangeCalculator.getTotalBitSize(members) +
				" >= (8 * sizeof(" + this.getType()+")))) {");
		builder.incrementAndIndent(getClass().getName());
		builder.appendAndIndent( "std::cerr << \"Packed-Type in \" << __FILE__ << \" too small. Either use bigger data type or append \" << std::endl << std::endl;" );
		builder.appendAndIndent( "std::cerr << \"  Packed-Type: " + this.getType() + " hint-size no-of-bits;  \" << std::endl << std::endl;" );
		builder.append(          "std::cerr << \"to your data type spec to guide DaStGen how many bits (no-of-bits) a data type has on your machine. DaStGen then can split up the bitfields into several attributes. \" << std::endl; ");
		builder.decrementAndIndent(getClass().getName());
		builder.appendAndIndent("}");
		builder.appendAndIndent(NameTranslatorFactory.getNameTranslator().getAssertion()
				+ "((" + RangeCalculator.getTotalBitSize(members) +
				" < (8 * sizeof(" + this.getType()+"))));");
	}
	
	/**
	 * @return the number of encapsulated members
	 */
	public int getNumberMembers() {
		return members.size();	
	}
	
	@Override 
	public void setPersistent(boolean persistent) {
		super.setPersistent(persistent);
		for (Member m: members) {
			m.setPersistent(persistent);
		}
	}
	
	public ArrayList<PackedMember> getMembers() {
		return members;
	}
	
	public boolean equals(Object obj) {
		boolean retVal =  super.equals(obj);
		return retVal;
	}
}
