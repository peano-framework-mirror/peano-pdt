// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.DastGenAST;


/**
 * A visitor encapsulated the traversal of the Abstract Syntax Tree (AST) as
 * well as the generation of code.
 * 
 * The intention is to place the code for the traversal of the AST here, 
 * and to create subclasses which generate the code.
 * 
 * @author Wolfgang Eckhardt
 */
public abstract class Visitor {

	public void process(CompilationUnit compilationUnit) {
		compilationUnitIn(compilationUnit);
		
		for (AbstractNode child: compilationUnit.getChildNodes()) {
		    child.applyVisitor(this);
		}
		
		compilationUnitOut(compilationUnit);
	}

	abstract protected void compilationUnitIn(CompilationUnit compilationUnit);
	
	abstract protected void compilationUnitOut(CompilationUnit compilationUnit);

	
	public void process(Class classObject) {
		classIn(classObject);
		
		for (Typedef typedef: classObject.getEnumTypedefs()) {
			typedef.applyVisitor(this);
		}
		
		for (Typedef typedef: classObject.getTypedefs()) {
			typedef.applyVisitor(this);
		}
		
		for (FriendDeclaration f: classObject.getFriends()) {
			f.applyVisitor(this);
		}
		
		for (Enumeration e: classObject.getEnumerations().values()) {
			e.applyVisitor(this);
		}
		
		for (ConstantMember cm: classObject.getConstantMembers()){
			cm.applyVisitor(this);
		}
		
		classObject.getStruct().applyVisitor(this);
		
		//TODO
		classOut(classObject);
	}

	abstract protected void classIn(Class classObject);

	abstract protected void classOut(Class classObject);

	
	public abstract void process(Include include);

	public abstract void process(Enumeration enumeration);
	
	public abstract void process(ConstantMember constantMember);

	public abstract void process(FriendDeclaration friendDeclaration);

	public abstract void process(Struct struct);

	public void process(Ifdef ifdef) {
		ifdefIn(ifdef);
		
		for (AbstractNode child: ifdef.getChildNodes()) {
			child.applyVisitor(this);
		}
		
		ifdefOut(ifdef);
	}
	
	protected abstract void ifdefIn(Ifdef ifdef);

	protected abstract void ifdefOut(Ifdef ifdef);

	public void process(IfdefBranch ifdefBranch) {
		ifdefBranchIn(ifdefBranch);
		
		for (AbstractNode child: ifdefBranch.getChildNodes()) {
			child.applyVisitor(this);
		}
		
		ifdefBranchOut(ifdefBranch);
	}

	protected abstract void ifdefBranchIn(IfdefBranch ifdefBranch);
	
	protected abstract void ifdefBranchOut(IfdefBranch ifdefBranch);

	public abstract void process(NamespaceDeclaration namespace);

	public abstract void process(Typedef typedef);
}
