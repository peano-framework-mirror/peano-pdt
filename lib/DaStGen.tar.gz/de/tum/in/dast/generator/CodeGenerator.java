// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;

import de.tum.in.dast.generator.DastGenAST.Class;
import de.tum.in.dast.generator.DastGenAST.CompilationUnit;
import de.tum.in.dast.generator.DastGenAST.ConstantMember;
import de.tum.in.dast.generator.DastGenAST.DaStGenASTBuilder;
import de.tum.in.dast.generator.DastGenAST.Enumeration;
import de.tum.in.dast.generator.DastGenAST.FriendDeclaration;
import de.tum.in.dast.generator.DastGenAST.Ifdef;
import de.tum.in.dast.generator.DastGenAST.IfdefBranch;
import de.tum.in.dast.generator.DastGenAST.Include;
import de.tum.in.dast.generator.DastGenAST.NamespaceDeclaration;
import de.tum.in.dast.generator.DastGenAST.Struct;
import de.tum.in.dast.generator.DastGenAST.Type;
import de.tum.in.dast.generator.DastGenAST.Typedef;
import de.tum.in.dast.generator.DastGenAST.Visitor;
import de.tum.in.dast.generator.conditionset.Conditional;
import de.tum.in.dast.generator.memberSelection.Member;
import de.tum.in.dast.generator.naming.NameTranslator;
import de.tum.in.dast.generator.naming.NameTranslatorFactory;
import de.tum.in.dast.generator.plugin.CodePlugin;
import de.tum.in.dast.generator.plugin.CodePluginFactory;
import de.tum.in.dast.properties.DaStProperties;
import de.tum.in.dast.util.DaStStringBuilder;

/**
 * Is ran by the code writer on the DaStGen AST. The produced
 * stream then is streamed to an output file by the CodeWriter
 * again.
 * 
 * The visitor basically handles one compilation unit, so please
 * consult CompilationUnit before studying this type.
 * 
 * @author Wolfgang Eckhardt, Tobias Weinzierl
 */
public class CodeGenerator extends Visitor {

	private DaStStringBuilder header;
  private DaStStringBuilder implementation;
	
  private boolean           currentClassIsPacked;
  
	private static DaStProperties buildDate = new DaStProperties("build-date.properties");
	
	private NameTranslator naming = NameTranslatorFactory.getNameTranslator();
	
	public CodeGenerator(
	    DaStStringBuilder header,
      DaStStringBuilder implementation
  ) {
		this.header = header;
    this.implementation = implementation;
	}

	@Override
	protected void classIn(Class classObject) {
		if (classObject.needsPragmas()) {
			generatePragmasIn(header);
		}
		
		currentClassIsPacked = classObject.isPacked();
		
		generateProlog();
		if ("".equals(classObject.getNamespace())) {
			header.append("class " + classObject.getClassname() + " { ");
		} else {
		header.append("class " + classObject.getNamespace() + "::" 
				+ classObject.getClassname() + " { ");
		}
		header.incrementAndIndent();
		header.indent();
		header.append("public:");
		header.incrementAndIndent();
		header.indent();
	}

	@Override
	protected void classOut(Class classObject) {
		
		header.append("private: ");
		header.incrementAndIndent();

		if (isAnyPersistentFieldExposed(classObject.getVirtualMembers()) && !classObject.isPacked()) {
		  header.appendAndIndent("public:\n");
	    header.appendAndIndent(naming.getPersistentRecords() + " " +
	        naming.getAttributeName(DaStGenASTBuilder.FIELD_PERSISTENT_RECORDS)+";");
	    header.appendAndIndent("private:\n");
		}
		else {
	    header.appendAndIndent(naming.getPersistentRecords() + " " +
	        naming.getAttributeName(DaStGenASTBuilder.FIELD_PERSISTENT_RECORDS)+";");
		}
		
		declareFields(classObject.getInternalMembers());
		
		header.decrementAndIndent();
		header.append("public:");
		header.incrementAndIndent();
		MethodGenerator methodGenerator = new MethodGenerator(header, implementation);
		methodGenerator.generateMethods(classObject);
		
		header.decrementIndentLevel();
		
		String classname = classObject.getClassname();
		
		if (!"".equals(classObject.getNamespace())) {
			classname = classObject.getNamespace() + "::" + classname;
		}
		
		ArrayList<Member> virtualMembers = classObject.getVirtualMembers();
		ArrayList<Member> internalMembers = new ArrayList<Member>(classObject.getStruct().getInternalMembers());
		internalMembers.addAll(classObject.getInternalMembers());
		
		for (CodePlugin plugin: CodePluginFactory.getCodePlugins()) {
			plugin.generateDefinition(DaStConfiguration.getConfiguration(), header, 
					classname, virtualMembers, internalMembers);
			plugin.generateImplementation(DaStConfiguration.getConfiguration(), implementation, 
					classname, classObject.getVirtualMembers(), internalMembers);
		}
		
		header.decrementAndIndent();
		header.append("};");
		header.indent(2);
		if (classObject.needsPragmas()) {
			generatePragmasOut(header);
		}
	}

	
	@Override
	public void process(Struct struct) {
		header.append("struct " + naming.getPersistentRecords() + " {");
		header.incrementAndIndent();

		// declaration of fields
		declareFields(struct.getInternalMembers());
		// declaration of methods
		
		MethodGenerator methodGenerator = new MethodGenerator(header, implementation);
		methodGenerator.generateMethods(struct);
		
		header.decrementAndIndent();
		header.appendAndIndent("};");
		header.decrementAndIndent();
	}
	
	/**
	 * Dreates the declaration of packed as well as non-packed members. Is used 
	 * for both the persistent and the non-persistent values.
	 * 
	 * @param members the members that should be declared
	 */
	private void declareFields(Collection<Member> members) {
		for (Member m : members) {
			m.writeDeclaration(header,currentClassIsPacked);
		}
	}
	
	private boolean isAnyPersistentFieldExposed(Collection<Member> members) {
	  boolean result = false;
    for (Member m : members) {
      result |= (m.isPersistent() && m.isExposed() );
    }
	  return result;
	}

	
	@Override
	protected void compilationUnitIn(CompilationUnit compilationUnit) {
		String qualifiedClassName = compilationUnit.getNamespace() + "::"
										+ compilationUnit.getName();
		header.appendAndIndent("#ifndef "+ naming.getIncludeGuard(qualifiedClassName));
		header.appendAndIndent("#define "+ naming.getIncludeGuard(qualifiedClassName));
		header.indent();
		
		implementation.append("#include \"" + naming.getIncludePath(qualifiedClassName) + "\"");
		implementation.indent(2);
	}

	@Override
	protected void compilationUnitOut(CompilationUnit compilationUnit) {
		header.appendAndIndent("#endif");
	}

	@Override
	protected void ifdefIn(Ifdef ifdef) {
		generateCompoundConditions("#if", ifdef.getConditions());
	}
	
	@Override
	protected void ifdefOut(Ifdef ifdef) {
		header.decrementAndIndent();
		header.append("#endif");
		header.indent(2);
		implementation.decrementAndIndent();
		implementation.append("#endif");
		implementation.indent(2);
	}
	
	@Override
	protected void ifdefBranchIn(IfdefBranch ifdefBranch) {
		header.decrementAndIndent();
		implementation.decrementAndIndent();
		generateCompoundConditions("#elif", ifdefBranch.getConditions());
	}
	
	@Override
	protected void ifdefBranchOut(IfdefBranch ifdefBranch) {
		header.decrementAndIndent();
		implementation.decrementAndIndent();
	}
	
	private void generateCompoundConditions(String iftype, Collection<Conditional> conditions) {
		Iterator<Conditional> iterator  = conditions.iterator();
		String currentCondition         = iterator.next().getStringRepresentation();
		header.append(iftype + " " + currentCondition);
		implementation.append(iftype + " " + currentCondition);
		while (iterator.hasNext()) {
			currentCondition = iterator.next().getStringRepresentation();
			header.append(" && "+currentCondition);
			implementation.append(" && "+currentCondition);
		}
		header.incrementAndIndent();
		implementation.incrementAndIndent();
	}


	@Override
	public void process(Include include) {
		header.appendAndIndent(include.getInclude());

	}

	@Override
	public void process(Enumeration enumeration) {
		ArrayList<String> values = enumeration.getValues();
		header.append("enum "+enumeration.getTypeString(false)+" {");
    	header.incrementAndIndent();
    	int numValues = values.size();
    	
    	for (int i = 0; i < numValues - 1; i++) {
    		header.append(values.get(i) +" = "+i + ", ");
    	}
    		
    	header.append(values.get(numValues - 1) + " = " + (numValues - 1)); // append the last value
    	
    	header.decrementAndIndent();
    	header.appendAndIndent("};");
    	header.indent();
	}
	
	@Override
	public void process(ConstantMember constantMember){
		header.append("static const " + constantMember.getType() + " " 
						+ constantMember.getIdentifier() + ";\n");
		header.indent();
		
		implementation.append("const " + constantMember.getType() + " "
						+ constantMember.getFullQualifiedIdentifier() + " = "  + constantMember.getValue()
						+ ";\n");
		implementation.indent();
	}

	@Override
	public void process(FriendDeclaration friendDeclaration) {
		header.indent();
		header.appendAndIndent("friend class "+friendDeclaration.getFriend()+";");
	}

	@Override
	public void process(NamespaceDeclaration namespaceDeclaration) {
		String namespace = namespaceDeclaration.getNamespace();

		if (!"".equals(namespace)) {

			int beginIndex = 0;
			int endIndex = 0;
			int numNamespaces = 0;
			while ((endIndex = namespace.indexOf(":", beginIndex)) > -1) {
				header.indent();
				header.append("namespace " + namespace.substring(beginIndex, endIndex) + " {");
				header.incrementIndentLevel();
				beginIndex = endIndex+2;
				numNamespaces++;
			}
			
			header.indent();
			header.append("namespace " + namespace.substring(beginIndex) + " {");
			header.incrementIndentLevel();
			numNamespaces++;

			for (String name: namespaceDeclaration.getClassnames()) {
				header.indent();
				header.append("class " + name + ";");
			}
			
			for (int i = 0; i < numNamespaces; i++) {
			header.decrementAndIndent();
			header.append("}");
			}
			header.indent(2);
		} else {
			for (String name: namespaceDeclaration.getClassnames()) {
				header.indent();
				header.append("class " + name + ";");
			}
			header.indent(2);
		}
	}
	
	
	
	private void generateProlog() {
	  SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy HH:mm");
		header.appendAndIndent("/**");
		header.appendAndIndent(" * @author This class is generated by DaStGen");
		header.appendAndIndent(" * \t\t   DataStructureGenerator (DaStGen)");
		header.appendAndIndent(" * \t\t   2007-2009 Wolfgang Eckhardt");
    header.appendAndIndent(" * \t\t   2012      Tobias Weinzierl");
		header.appendAndIndent(" *");
		header.appendAndIndent(" * \t\t   build date: "+buildDate.getProperty("build-date"));
		header.appendAndIndent(" *");
		header.appendAndIndent(" * @date   " + format.format(new Date())); 
		header.appendAndIndent(" */");
  }
	
	
	private void generatePragmasIn(DaStStringBuilder builder) {
			String packedRecords = NameTranslatorFactory.getNameTranslator().getCFPackedRecords();
			
			builder.appendAndIndent("#ifndef DaStGenPackedPadding");
			builder.appendAndIndent("  #define DaStGenPackedPadding 1      // 32 bit version");
			builder.appendAndIndent("  // #define DaStGenPackedPadding 2   // 64 bit version");
			builder.appendAndIndent("#endif");

			builder.appendAndIndent(""); 
			builder.appendAndIndent(""); 
		    
			builder.append("#ifdef "+packedRecords);
			builder.incrementAndIndent();
			builder.append("#pragma pack (push, DaStGenPackedPadding)");
			builder.decrementAndIndent();
			builder.appendAndIndent("#endif");
			builder.indent();
	}
	
	private void generatePragmasOut(DaStStringBuilder builder) {
		String packedRecords = NameTranslatorFactory.getNameTranslator().getCFPackedRecords();
		builder.appendAndIndent("#ifdef "+packedRecords);
		builder.appendAndIndent("#pragma pack (pop)");
		builder.appendAndIndent("#endif");
		builder.indent(2);
	}

	@Override
	public void process(Typedef typedef) {
		Type type = typedef.getType();
		header.appendAndIndent("typedef " + type.getTypeString(true) + " "
				+ typedef.getAlias() + ";");
		header.indent();
	}
}
