// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.DastGenAST;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import de.tum.in.dast.generator.ConditionalDepthFirstAdapter;
import de.tum.in.dast.generator.conditionset.Conditional;
import de.tum.in.dast.node.AClassheader;
import de.tum.in.dast.node.AClassname;
import de.tum.in.dast.node.AConstantDeclaration;
import de.tum.in.dast.node.ANamespace;
import de.tum.in.dast.node.APackedTypeDeclaration;
import de.tum.in.dast.node.ASizeSpecification;
import de.tum.in.dast.node.AValueSpecification;
import de.tum.in.dast.node.Start;

/**
 * Traverse a sableCC tree and select the data which will not be directly 
 * contained in the generated code (e.g. the packed bitfield type)
 * 
 * @author eckhardw
 */
public class MetadataSelector extends ConditionalDepthFirstAdapter {

	// the className, which was read as last 
	private StringBuilder classnameRead = new StringBuilder();
	
	private String classname;
	private String namespace;
	
	// holds the type of the bitfield for packed Members
	private Type packedFieldType = null;
	
	private TreeMap<String, Size> constantSizes = new TreeMap<String, Size>();
	
	
	public MetadataSelector(Set<Conditional> selectedConditions) {
		super(selectedConditions);
	}

	public void selectMetadata(List<Start> trees) {
		for (Start tree: trees) {
			tree.apply(this);
		}
	}
	
	@Override
	public void outAClassheader(AClassheader node) {
	
		classname = "";
		namespace = "";
		
		if (classnameRead.indexOf(":") > 0) {
			namespace = classnameRead.substring(0, classnameRead.lastIndexOf(":")-1);
			classname = classnameRead.substring(classnameRead.lastIndexOf(":")+1);
		} else {
			classname = classnameRead.toString();
		}
	}
	
	@Override
	public void inAClassname(AClassname node) {
		classnameRead = new StringBuilder();
	}
	
	@Override
	public void outAClassname(AClassname node) {
		classnameRead.append(node.getIdentifier().getText());
	}

	public void inANamespace(ANamespace node) {
		classnameRead.append(node.getIdentifier().getText()+"::");
	}
	
	
	@Override
	public void caseAPackedTypeDeclaration(APackedTypeDeclaration node) {
		String field = node.getTypeSpecifier().toString();
		packedFieldType = new Type(field.substring(0, field.length() - 1), "");
		if (node.getSizeSpecification() != null) {
			ASizeSpecification specification = (ASizeSpecification)node.getSizeSpecification();
			String sizeString = specification.getDecimalConstant().getText();
			Size size = new Size(sizeString);
			packedFieldType.setSize(size);
		}
	}

	
	@Override
	public void inAConstantDeclaration(AConstantDeclaration node) {
		String value = node.getIdentifier().getText();
		int intValue = -1;
		if (node.getValueSpecification() != null) {
			AValueSpecification vsp =  (AValueSpecification)node.getValueSpecification();
			intValue = Integer.parseInt(vsp.getDecimalConstant().getText());
		}
		Size size = new Size(value, intValue);
		constantSizes.put(value, size);
	}
	
    public String getClassname() {
		return classname;
	}
    
    public String getNameSpace() {
    	return namespace;
    }
    
    public Type getPackedFieldType() {
    	return packedFieldType;
    }
    
    public Map<String, Size> getConstantSizes()  {
    	return constantSizes;
    }
}
