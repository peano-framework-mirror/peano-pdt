// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.naming;

import de.tum.in.dast.generator.DastGenAST.Type;

/**
 * Implementation of the NameTranslator interface for the Peano project:
 * 
 * - within the names there's no underscore used
 * - different words start with uppercase
 * - attributes start with an underscore
 * - all operations start with a verb
 *
 * @author Tobias Weinzierl
 */
public class PeanoHeapNameTranslator implements NameTranslator {

	/**
	 * Removes all the underscores inside name and makes the 
	 * following letter uppercase.
	 */
	private String removeUnderscores(String name) {
		StringBuffer result = new StringBuffer( name );
		result.trimToSize();
		while ( result.indexOf("_")!=-1 ) {
			int indexOfUnderscore = result.indexOf("_");
			result.deleteCharAt(indexOfUnderscore);
			if ( (indexOfUnderscore < result.length()) && (indexOfUnderscore!=0) ) {
				result.setCharAt(
						indexOfUnderscore, 
						Character.toUpperCase(result.charAt(indexOfUnderscore))
				);
			} 
		}
		return result.toString();
	}

	public String getAttributeName(String name) {
		return "_"+removeUnderscores(name);
	}

	private String makeFirstLetterUppercase(String name) {
		StringBuffer result = new StringBuffer( name );
		result.setCharAt(
				0, 
				Character.toUpperCase(result.charAt(0))
		);
		return result.toString();    
	}
	

	public String getBitArrayFlipOperationName(String name) {
	  return "flip" + makeFirstLetterUppercase(
				removeUnderscores(name)
		);  
	}
	

	public String getGetter(String name) {
		return "get" + makeFirstLetterUppercase(
				removeUnderscores(name)
		);
	}

	public String getSetter(String name) {
		return "set" + makeFirstLetterUppercase(
				removeUnderscores(name)
		);
	}

	public String getArgumentName(String name) {
		return removeUnderscores(name);
	}

	public String getPersistentRecords() {
		return "PersistentRecords";
	}

	public String getIncludeGuard(String qualifiedClassName) {
		String result = "_";
		result += qualifiedClassName.replaceAll("::", "_");
		result += "_H";
		result = result.toUpperCase();
		return result;
	}


	public String getIncludePath(String qualifiedClassName) {	  
		String include;
		if (qualifiedClassName.contains("::")) {
			include = "";
			while (qualifiedClassName.indexOf(":")!=-1) {
			  String newSubstring = qualifiedClassName.substring(0, qualifiedClassName.indexOf(":")); 
			  qualifiedClassName  = qualifiedClassName.substring(qualifiedClassName.indexOf(":")+2);
        include += newSubstring;
  			include += "/";
      }
			include += qualifiedClassName.substring(qualifiedClassName.lastIndexOf(":") + 1);
		} else {
			include = qualifiedClassName;
		}
		return include + ".h";
	} 

	public String getAssertion() {
		return "assertion";
	}
	
	public String[] getIncludes() {
		String[] includes = { 
      "#include <iostream>",
	    "#include <string>",
      "#include <complex>",
      "#include <bitset>",
      "#include \"tarch/la/Vector.h\"",
      "#include \"tarch/logging/Log.h\"",
      "#ifdef Parallel\n\t#include <mpi.h>\n#endif",
      "#ifdef Parallel\n\t#include \"tarch/parallel/Node.h\"\n#endif",
      "#include \"peano/utils/PeanoOptimisations.h\"",
      "#include \"tarch/compiler/CompilerSpecificSettings.h\""
		};
		return includes;
	}

	public String getCFPackedRecords() {
		return "PackedRecords";
	}
	
	 public String getCFVectorAlignment() {
	   return "UseManualAlignment";
	 }


//	@Override java 1.5 doesn't accept override annotation for interfaces
	public String getClassnameForPackedClass(String classname) {
		return (classname + "Packed");
	}
	
	public String getClassnameForFlatClass(String classname) {
		return classname;
	}


	public Type getArrayDataType(Type typeObject, String arrayLength) {
		return new TinyVectorType(typeObject, arrayLength);
	}
	
 
	public boolean isDestructorVirtual() {
	  return false;
	}
}
