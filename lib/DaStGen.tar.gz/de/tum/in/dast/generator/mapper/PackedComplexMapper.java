// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.mapper;

import de.tum.in.dast.generator.DastGenAST.Size;
import de.tum.in.dast.generator.DastGenAST.Type;
import de.tum.in.dast.generator.memberSelection.Member;
import de.tum.in.dast.generator.naming.NameTranslatorFactory;
import de.tum.in.dast.util.DaStStringBuilder;


/**
 * Implementation of a Mapper to support packed doubles.
 * 
 * Packs doubles which bit-representations conforms to the IEEE 754 Standard, 
 * into short ints, making use of a similar format. 
 * 
 *  The IEEE 754 standard specifies double precision values to be of length 64 bit.
 *  
 *      | sgn |   exponent   |  mantissa              |
 * Bit   63    62          52 51                     0
 * 
 * The MSB (Bit 63) indicates the sign, the exponent is contained in the next 
 * 11 bits,shifted by 2^("length-of-field" - 1) - 1, i.e. for double precision 
 * by 2^(11 - 1) - 1 = 1023.
 * The last 52 bits contain the fraction of the mantissa, which is normalized 
 * to 1.xxxx (so there is always a trailing 1, which does not need to be saved.)  
 * 
 * This packer changes this representation by truncating the fraction part and 
 * reducing the range of the exponent to the following one: 
 *  
 *      | sgn |   exponent   |  mantissa            |
 * Bit   15    14           8 7                    0
 * 
 * This implies, the number represented may be in the order of 2^-63 to 2^64 
 * with a precision of the mantissa of 3.90625 * 10^-3
 * 
 * Further more the generated code is based on the following assumptions
 * - type short int is at least 16 bits long
 * - type long long int is at least 64 bits long
 * - type double is exactly 64 bits long and conforms to IEEE 754 standard
 * 
 * 
 * Please note, that the support for doubles introduces some inconsistencies to DaSTGen, 
 * as at the moment some assumptions for packed variables don't hold any longer:
 * 	- all packed variables are stored into a bitfield, managed by the "packer".
 * 		- GetBitfieldLength() returns "0" to make the packer ignore packed doubles, 
 * 			although their length is 16 bits.
 *  	- Each packed double is packed into a short int of the name of the member.
 *  - for the declaration of the packed records, the packed doubles have to be in the
 *    set XXXPackedMembers, but they must not be taken into account for generating
 *     the comment for the packed records. Instead, the variables they are mapped to, have
 *     to be declared.   
 *  - DaStGen insists on a Packed-Type declaration for the bitfield, even if only packed 
 *  	doubles are declared and though this setting has no influence on the code generated.
 *     
 * The clean way was to support the packed records to span several bitfields, then all packed
 * variables could be treated uniformly. 
 * 
 * 
 * Implementation of getter- / setter is pretty clumsy, because:
 * - there is no ISO-C++ (long long int is not part of ISO-C++!) data type whith the same length 
 * 		as double
 * - can't cast double-pointers to anything else than char* (because otherwise we break the rule
 * 		of strict-aliasing - required by ISO-C++)
 * - any other ideas for a sensible implementation???   
 * 
 * @author Wolfgang Eckhardt
 *
 */
public class PackedComplexMapper extends SimpleMapper {

	// the type for packed doubles
	public static String mappedType = "int";
	
	public PackedComplexMapper(Member member) {
		super(member, new Type(Type.DOUBLE, ""));
	}
	
	@Override
	public String getGetMethodBody(Member member) {
		DaStStringBuilder builder = new DaStStringBuilder();
		builder.incrementIndentLevel();
		
		String memberName = member.getMappedVariable();
	
		// create the memory for the creation of the return value
		builder.appendAndIndent("int tmp = 0;");
		
		// extract the sign and shift it to its possition
		//  tmp |= ((save & 0x8000) << 16);
		builder.appendAndIndent("tmp |= ((" + memberName + "& 0x8000) << 16);");
		
		// extract the exponent, correct the bias, and set it 
		// int exponent = ((save & 0x7f00) >> 8);
		// exponent = exponent - 63 + 1023;
		// tmp |= (exponent << 20); 
	
		builder.appendAndIndent("int exponent = ((" + memberName + " & 0x7f00) >> 8);");
		builder.appendAndIndent("exponent = exponent - 63 + 1023;");
		builder.appendAndIndent("tmp |= (exponent << 20);");
		
		// set the mantissa 
		// tmp = ((save & 0x00ff) << 12);
		builder.appendAndIndent("tmp |= ((" + memberName + " & 0x00ff) << 12);");
		
		// create the return value and copy memory 
		// char* double_ptr = reinterpret_cast<char*> (&result) + 4; // set to upper "int"
	    // char* int_ptr = reinterpret_cast<char*> (&tmp);
	    // for (int i = 0; i < 4; i++)
	    //   {
	    //     *double_ptr = *int_ptr;
	    //     int_ptr++;
	    //     double_ptr++;
	    //   }
		builder.appendAndIndent("double result = 0;");
		builder.appendAndIndent("char* double_ptr = reinterpret_cast<char*> (&result) + 4;");
		builder.appendAndIndent("char* int_ptr = reinterpret_cast<char*> (&tmp);");
		builder.appendAndIndent("*double_ptr = *int_ptr;");
		builder.appendAndIndent("*(double_ptr + 1) = *(int_ptr + 1);");
		builder.appendAndIndent("*(double_ptr + 2) = *(int_ptr + 2);");
		builder.appendAndIndent("*(double_ptr + 3) = *(int_ptr + 3);");
		builder.indent();
		builder.appendAndIndent("return result;");
		
		return builder.toString();
	}
	
	
	@Override
	public String getSetMethodBody(Member member) {
		DaStStringBuilder builder = new DaStStringBuilder();
		builder.incrementIndentLevel();
	
		// create the temporary memory and copy the memory.
		//int tmp = 0;
	    //char* double_ptr = reinterpret_cast<char*> (&val) + 4; // set to upper "int"
	    //char* int_ptr = reinterpret_cast<char*> (&tmp);
		builder.appendAndIndent("int tmp = 0;");
		builder.appendAndIndent("const char* double_ptr = reinterpret_cast<const char*> (&"
				+ translator.getArgumentName(member.getMemberName()) + ") + 4;");
		builder.appendAndIndent("char* int_ptr = reinterpret_cast<char*> (&tmp);");
		
		// copy the bytes
		builder.appendAndIndent("*int_ptr = *double_ptr;");
		builder.appendAndIndent("*(int_ptr + 1) = *(double_ptr + 1);");
		builder.appendAndIndent("*(int_ptr + 2) = *(double_ptr + 2);");
		builder.appendAndIndent("*(int_ptr + 3) = *(double_ptr + 3);");
		
		// tmp = tmp >> 12;
		builder.appendAndIndent("tmp = tmp >> 12;");
	    builder.indent();
		// last 8 bits of tmp (representing the MSBs of the fraction) are the last 8 bits of 
		// our reduced accuracy value 
		// short int save =  tmp & 0xff;
		
		String memberName = member.getMappedVariable();
		builder.appendAndIndent(memberName +" = tmp & 0xff;");
		
		// extract the exponent
		// int exp = (tmp & 0x007ff00) >> 8;
		builder.appendAndIndent("short int exponent = (tmp & 0x0007ff00) >> 8;");
		
		// correct the bias
		// exp = exp - 1023 + 63;
		builder.appendAndIndent("exponent = exponent - 1023 + 63;");
		
		// save |= exp << 8;
		builder.appendAndIndent(memberName + " |= (exponent << 8);");
		
		// save |= (tmp >> 4) & 0x8000;
		builder.appendAndIndent(memberName + " |= (tmp >> 4) & 0x8000;");
		
		return builder.toString();	
	}
	
		
	/**
	 * @return "0". Up to now, there is a field of type short int 
	 * declared, where the packed double is packed to. So this member does not
	 * need any space in the bitfield all other variables are packed into.
	 * 
	 * N.B. Probably this is no consistent model and should be refactored. 
	 */
	public Size getBitfieldLength() {
		return new Size(16);
	}

	@Override
	public void writeDeclaration(DaStStringBuilder builder, boolean currentClassIsPacked) {
		builder.append("short int "
				+translator.getAttributeName(member.getMemberName()+";"));
		builder.decrementAndIndent();
	}
	
	public void writeConstructorAssertions(DaStStringBuilder builder) {
		builder.appendAndIndent(NameTranslatorFactory.getNameTranslator().getAssertion()
				+ "((sizeof(short int) >= 2));");
		builder.appendAndIndent(NameTranslatorFactory.getNameTranslator().getAssertion()
				+ "((sizeof(double) == 8));");
	}
}
