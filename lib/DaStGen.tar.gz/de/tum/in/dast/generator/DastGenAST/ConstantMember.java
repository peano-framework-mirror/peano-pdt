// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.DastGenAST;

/**
 * Represents a constant member of a class.
 * @author unterweg
 *
 */
public class ConstantMember implements AbstractNode {
	
	private String identifier;
	
	private String type;
	
	private String value;
	
	private String qualification;
	
	//Constructor
	public ConstantMember(String identifier, String type, String value, String qualification){
		this.identifier = identifier;
		this.type = type;
		this.value = value;
		this.qualification = qualification;
	}

	public void applyVisitor(Visitor visitor) {
		visitor.process(this);
	}
	
	/**
	 * Returns the basic identifier of this constant member, i.e. the simple name
	 * of this constant.
	 * @return
	 */
	public String getIdentifier(){
		return identifier;
	}
	
	public String getFullQualifiedIdentifier(){
		if("".equals(qualification)){
			return identifier;
		} else {
			return qualification + "::" + identifier;
		}
	}
	
	public String getType(){
		return type;
	}
	
	public String getValue(){
		return value;
	}
	
	public String getQualification(){
		return qualification;
	}

}
