// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.util;

import java.util.Collection;
import java.util.StringTokenizer;

import de.tum.in.dast.generator.DastGenAST.Size;
import de.tum.in.dast.generator.memberSelection.PackedMember;

/**
 * This class takes a range of integers and calculates the
 * number of bits that are needed to store the range
 * 
 * @author Wolfgang Eckhardt
 *
 */
public class RangeCalculator {
	
	/* constant needed for change of logarithm base */
	private static double ln2 = Math.log(2);
	
	/**
	 * calculates the number of bits that are needed to store 
	 * numbers in the range from start to end, includes both 
	 * start and end; 
	 * 
	 * example: calculateBits (0, 3) returns 2;
	 * 			calculateBits (1, 4) returns 2;
	 * 			calculateBits (0, 4) returns 3;
	 * 
	 * @param start the start of the range
	 * @param end the end of the range
	 * @return the number of bits needed to store the range
	 */
	public static Size calculateBits(int start, int end) {
		int rangeWidth = Math.abs(end - start) + 1;
		if (rangeWidth == 1) {
			return new Size(1);
		}
		double log =  Math.log(rangeWidth) / ln2;
		Size size = new Size((int) Math.ceil(log));
		return size;
	}
	
	/**
	 * Calculates the total bitlength, the packedmembers need. Cumulates all
	 * numeric values into one single value, and then adds all symbolic values.
	 * 
	 * @param members the members, whose length should be calculated
	 * @return the string, expressing the total length. 
	 * 			e.g. for members, who need the length 3, 6, DIMENSION the result is
	 * 			"9 + DIMENSION"
	 * 
	 */
	public static String getTotalBitSize(Collection<PackedMember> members) {
		String result = "";
		int length = 0;
		for(PackedMember member: members) {
			try {
				length += Integer.parseInt(member.getBitfieldLength().getStringRepresentation());
				
			} catch (NumberFormatException nfe) {
				result = result + member.getBitfieldLength().getStringRepresentation() + "+";
			}
		}
		
		result += length;
		return result;
	}
	
	/**
	 * Calculates the total bitOffset of the bitfield of a packed member. Cumulates all
	 * numeric values into one single value, and then adds all symbolic values.
	 * 
	 * @param members the members, whose length should be calculated
	 * @return the string, expressing the total length. 
	 * 			e.g. for members, who need the length 3, 6, DIMENSION the result is
	 * 			"9 + DIMENSION"
	 */
	public static String getTotalBitSize(PackedMember member) {
		return getTotalBitSize(member.getStartIndex());
	}
	
	public static String getTotalBitSize(String size) {
		String result = "";
		int offset = 0;
		StringTokenizer tokenizer = new StringTokenizer(size, "+"); 
		while (tokenizer.hasMoreTokens()) {
			String next = tokenizer.nextToken();
			next = next.trim();
			try {
				offset += Integer.parseInt(next);
			} catch (NumberFormatException nfe) {
				result = result + next + " + ";
			}
		}
		
		result += offset;
		return result;
	}

}
