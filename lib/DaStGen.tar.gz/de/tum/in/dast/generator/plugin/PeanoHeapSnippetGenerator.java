// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.plugin;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import de.tum.in.dast.generator.DaStConfiguration;
import de.tum.in.dast.generator.DastGenAST.DaStGenASTBuilder;
import de.tum.in.dast.generator.DastGenAST.Type;
import de.tum.in.dast.generator.mapper.MapperFactory;
import de.tum.in.dast.generator.memberSelection.Member;
import de.tum.in.dast.generator.memberSelection.PackedMember;
import de.tum.in.dast.generator.naming.NameTranslator;
import de.tum.in.dast.generator.naming.NameTranslatorFactory;
import de.tum.in.dast.util.DaStStringBuilder;

public class PeanoHeapSnippetGenerator implements CodePlugin {
	
	public void generateDefinition(DaStConfiguration configuration, 
			DaStStringBuilder stringBuilder, String qualifiedClassName, List<Member> virtualMembers, List<Member> internalMembers) {
		
		System.out.println( "*** use PeanoHeapSnippetGenerator" );

		stringBuilder.indent();
		stringBuilder.append("#ifdef Parallel");
		stringBuilder.incrementAndIndent();
		
		// write code for attributes
		
		stringBuilder.append("protected:");
		stringBuilder.incrementAndIndent();
		stringBuilder.appendAndIndent("static tarch::logging::Log _log;");  
		stringBuilder.decrementAndIndent();

		// write code for methods
		stringBuilder.append("public:");
		stringBuilder.incrementAndIndent();
		stringBuilder.indent();
		stringBuilder.appendAndIndent("/**");
		stringBuilder.appendAndIndent(" * Global that represents the mpi datatype.");
		stringBuilder.appendAndIndent(" * There are two variants: Datatype identifies only those attributes marked with");
		stringBuilder.appendAndIndent(" * parallelise. FullDatatype instead identifies the whole record with all fields.");
		stringBuilder.appendAndIndent(" */");
		stringBuilder.appendAndIndent("static MPI_Datatype Datatype;");
		stringBuilder.append("static MPI_Datatype FullDatatype;");
		stringBuilder.indent(2);
		
		stringBuilder.appendAndIndent("/**");
		stringBuilder.appendAndIndent(" * Initializes the data type for the mpi operations. Has to be called");
		stringBuilder.appendAndIndent(" * before the very first send or receive operation is called.");
		stringBuilder.appendAndIndent(" */");
		stringBuilder.appendAndIndent("static void initDatatype();");
		stringBuilder.indent();
        stringBuilder.appendAndIndent("static void shutdownDatatype();");
        stringBuilder.indent();
		stringBuilder.appendAndIndent("/**");
		stringBuilder.appendAndIndent(" * @param communicateSleep -1 Data exchange through blocking mpi");
		stringBuilder.appendAndIndent(" * @param communicateSleep  0 Data exchange through non-blocking mpi, i.e. pending messages are received via polling until MPI_Test succeeds");
		stringBuilder.appendAndIndent(" * @param communicateSleep >0 Same as 0 but in addition, each unsuccessful MPI_Test is follows by an usleep");
		stringBuilder.appendAndIndent(" */");
		stringBuilder.appendAndIndent("void send(int destination, int tag, bool exchangeOnlyAttributesMarkedWithParallelise, int communicateSleep);");
		stringBuilder.indent();
		stringBuilder.appendAndIndent("void receive(int source, int tag, bool exchangeOnlyAttributesMarkedWithParallelise, int communicateSleep);");
		stringBuilder.indent();
		stringBuilder.appendAndIndent("static bool isMessageInQueue(int tag, bool exchangeOnlyAttributesMarkedWithParallelise);");
		stringBuilder.indent();

		stringBuilder.append("#endif");
		stringBuilder.incrementAndIndent();
	}
	

	
	
	public void generateImplementation(DaStConfiguration configuration, 
		DaStStringBuilder stringBuilder, String qualifiedClassName, List<Member> virtualMembers, List<Member> internalMembers) {
		
		stringBuilder.append("#ifdef Parallel");
		stringBuilder.incrementAndIndent();
		
		stringBuilder.appendAndIndent("tarch::logging::Log "+qualifiedClassName+"::_log( \""+qualifiedClassName+"\" );");
		stringBuilder.indent();
		stringBuilder.appendAndIndent("MPI_Datatype "+qualifiedClassName+"::Datatype = 0;");
		stringBuilder.appendAndIndent("MPI_Datatype "+qualifiedClassName+"::FullDatatype = 0;");
		stringBuilder.indent();
		
		generateMPIInit(internalMembers, stringBuilder, qualifiedClassName);
		generateMPIShutdown(stringBuilder, qualifiedClassName);
		generateSendMethod(stringBuilder, qualifiedClassName);
		generateReceiveMethod(stringBuilder, qualifiedClassName);
		generateIsMessageInQueueMethod(stringBuilder, qualifiedClassName);

		stringBuilder.decrementAndIndent();
		stringBuilder.appendAndIndent("#endif");
		stringBuilder.indent(2);
	}
	
	private void generateMPIShutdown(DaStStringBuilder builder, String className) {
		builder.indent();
                builder.append("void "+className+"::shutdownDatatype() {");
                builder.incrementAndIndent();

                String simpleClassName = className.substring(className.lastIndexOf(":")+1);

                builder.appendAndIndent("MPI_Type_free( &"+simpleClassName+"::Datatype );");
                builder.appendAndIndent("MPI_Type_free( &"+simpleClassName+"::FullDatatype );");
                builder.decrementAndIndent();
                builder.appendAndIndent("}");
                builder.indent();
	}


	private void generateMPIInit(List<Member> members, DaStStringBuilder builder, String className) {
		//if (!DaStConfiguration.generateParallelCode || CodeGenerator.getState() == State.OUTER_UNPACKED) {
		// TODO the "problem" of generating mpi_init for not packed data is rooted in
		// single boolean values and boolean arrays => how to send a std::bitset???
		// the answer could give each Mapper, then the code below would become much simpler anyway.
		// Moreover the generation of parallel code should be determined only by the boolean flag. 
		// => extract the settings to application wide settings, as suggested in main class?
		//	return;
		//}
		
	  NameTranslator translator      = NameTranslatorFactory.getNameTranslator();
    String         simpleClassName = className.substring(className.lastIndexOf(":")+1);

    builder.indent();
    builder.append("void "+className+"::initDatatype() {");
    builder.incrementAndIndent();

		List<Member> parallelMembers = (List<Member>) new ArrayList<Member>();
		for (Member m: members) {
			if (m.isParallel()) {
				parallelMembers.add(m);
			}
		}
    Collections.sort(parallelMembers);
		
    builder.append("{");
    builder.incrementAndIndent();
		initMPIDatatype(
		  builder, className, simpleClassName,
      parallelMembers, translator,
      simpleClassName+"::Datatype"
    );
		builder.decrementAndIndent();
		builder.appendAndIndent("}");

		
    List<Member> allMembers = (List<Member>) new ArrayList<Member>();
    for (Member m: members) {
      allMembers.add(m);
    }
    Collections.sort(allMembers);

    builder.append("{");
    builder.incrementAndIndent();
    initMPIDatatype(
      builder, className, simpleClassName,
      allMembers, translator,
      simpleClassName+"::FullDatatype"
    );
    builder.decrementAndIndent();
    builder.appendAndIndent("}");
				
		builder.decrementAndIndent();
		builder.appendAndIndent("}");
		builder.indent();
	}




  private void initMPIDatatype(
    DaStStringBuilder builder, String className, String simpleClassName,
    List<Member> parallelMembers, NameTranslator translator,
    String mpiDatatypeName
  ) {
    int numParallelMembers = 0;
    for (Member m: parallelMembers) {
      numParallelMembers += (Type.COMPLEX.equals(m.getType()) && m.getArraySize()==null) ? 2 : 1;
    }
		
	    builder.appendAndIndent(simpleClassName+" dummy"+simpleClassName+";");
	    builder.indent();

		/**
		 * Create MPI datastructure for attributes marked with parallelise 
		 * 
		 */
      	builder.appendAndIndent("const int Attributes = "+(numParallelMembers)+";");
		builder.append("MPI_Datatype subtypes[Attributes] = {");
		builder.incrementAndIndent();

		String separator = " ";
		for (Member m: parallelMembers) {
			// Bugfix for packed doubles
			if (Type.DOUBLE.equals(m.getType()) && m.isPacked() && MapperFactory.supportPackedDoubles) {
				builder.appendAndIndent( separator + " " + Type.getMPIType(((PackedMember) m).getPackedType(), false)+"\t\t //"+m.getMemberName());
			} 
			else if (Type.COMPLEX.equals(m.getType()) && m.getArraySize()==null) {
                builder.appendAndIndent(separator + " " + Type.getMPIType(m.getType(), false)+"\t\t //"+m.getMemberName());
                builder.appendAndIndent(", " + Type.getMPIType(m.getType(), false)+"\t\t //"+m.getMemberName());
			}
			else {
				boolean isArray = (m.getArraySize() != null);
				builder.appendAndIndent(separator + " " + Type.getMPIType(m.getType(), isArray)+"\t\t //"+m.getMemberName());
			}
			separator= ",";
		}
		
		builder.decrementAndIndent();
		builder.appendAndIndent("};");
		builder.indent();
		
		builder.append("int blocklen[Attributes] = {");
		builder.incrementAndIndent();
		separator = " ";
		for (Member m: parallelMembers) {
          if (Type.COMPLEX.equals(m.getType())&& m.getArraySize()==null) {
            builder.appendAndIndent(separator + " 1\t\t //"+m.getMemberName());       
            builder.appendAndIndent(", 1\t\t //"+m.getMemberName());       
          }
          else if (Type.COMPLEX.equals(m.getType())&& m.getArraySize()!=null) {
            builder.appendAndIndent(separator + " " + m.getArraySize().getStringRepresentation()+"*2\t\t //"+m.getMemberName());       
          }
          else if (m.getArraySize() != null) {
     	      builder.appendAndIndent(separator + " " + m.getArraySize().getStringRepresentation()+"\t\t //"+m.getMemberName());		    
	   	  }
          else {
            builder.appendAndIndent(separator + " 1\t\t //"+m.getMemberName());       
          }
          separator= ",";
		}
		builder.decrementAndIndent();
		builder.appendAndIndent("};");
		builder.indent();

		builder.appendAndIndent("MPI_Aint     disp[Attributes];");
		builder.indent();
		
		builder.appendAndIndent("MPI_Aint base;");
		builder.appendAndIndent("MPI_Get_address( const_cast<void*>(static_cast<const void*>(&(dummy"+ simpleClassName +"))), &base);");		

		int elementNumber = 0;
        for (Member m: parallelMembers) {
    		String memberName = "";
			if (m.isPersistent()) {
				memberName = "dummy"+simpleClassName + "." 
					+ translator.getAttributeName(DaStGenASTBuilder.FIELD_PERSISTENT_RECORDS) 
					+ "." + translator.getAttributeName(m.getMemberName());
			} else {
				memberName = "dummy"+simpleClassName + "." 
				+ translator.getAttributeName(m.getMemberName());
			}
			if (m.getArraySize() != null && !Type.BOOL.equals(m.getType())) {
     	      builder.appendAndIndent("MPI_Get_address( const_cast<void*>(static_cast<const void*>(&(" + memberName+"[0]))), \t\t&disp["+elementNumber+"] );");
			} 
            else if (Type.COMPLEX.equals(m.getType())) {
              builder.appendAndIndent("MPI_Get_address( const_cast<void*>(static_cast<const void*>(&(reinterpret_cast<double*>(" + memberName+")[0] ))), \t\t&disp["+elementNumber+"] );");
              elementNumber++;
              builder.appendAndIndent("MPI_Get_address( const_cast<void*>(static_cast<const void*>(&(reinterpret_cast<double*>(" + memberName+")[1] ))), \t\t&disp["+elementNumber+"] );");
             }
			else {
     	      builder.appendAndIndent("MPI_Get_address( const_cast<void*>(static_cast<const void*>(&(" + memberName+"))), \t\t&disp["+elementNumber+"] );");
			}
			elementNumber++;
		}
		
		builder.append("for (int i=1; i<Attributes; i++) {");
		builder.incrementAndIndent();
		builder.append("assertion1( disp[i] > disp[i-1], i );");
		builder.decrementAndIndent();
		builder.appendAndIndent("}");
		
		builder.append("for (int i=0; i<Attributes; i++) {");
		builder.incrementAndIndent();
		builder.append("disp[i] = MPI_Aint_diff(disp[i], base);");
		builder.decrementAndIndent();
		builder.appendAndIndent("}");
		
		builder.appendAndIndent("MPI_Datatype tmpType; ");
		builder.appendAndIndent("MPI_Aint lowerBound, typeExtent; ");

		builder.appendAndIndent("MPI_Type_create_struct( Attributes, blocklen, disp, subtypes, &tmpType );" );
		builder.appendAndIndent("MPI_Type_get_extent( tmpType, &lowerBound, &typeExtent );" );
		builder.appendAndIndent("MPI_Type_create_resized( tmpType, lowerBound, typeExtent, &"+mpiDatatypeName+" );");

		builder.appendAndIndent("MPI_Type_commit( &"+mpiDatatypeName+" );");  
    }

  
	public void generateSendMethod(DaStStringBuilder stringBuilder, String className) {
		
		//Send Operation
	stringBuilder.append("void "+className+"::send(int destination, int tag, bool exchangeOnlyAttributesMarkedWithParallelise, int communicateSleep) {");
	stringBuilder.incrementAndIndent();
    stringBuilder.appendAndIndent("if (communicateSleep<0) {");
    stringBuilder.incrementAndIndent();
    stringBuilder.appendAndIndent("const int result = MPI_Send(this, 1, exchangeOnlyAttributesMarkedWithParallelise ? Datatype : FullDatatype, destination, tag, tarch::parallel::Node::getInstance().getCommunicator());");
    stringBuilder.append("if  (result!=MPI_SUCCESS) {");
    stringBuilder.incrementAndIndent();
    stringBuilder.appendAndIndent("std::ostringstream msg;");
    stringBuilder.appendAndIndent("msg << \"was not able to send message "+className+" \"");
    stringBuilder.appendAndIndent("<< toString()");
    stringBuilder.appendAndIndent("<< \" to node \" << destination");
    stringBuilder.appendAndIndent("<< \": \" << tarch::parallel::MPIReturnValueToString(result);");
    stringBuilder.append("_log.error( \"send(int)\",msg.str() );");
    stringBuilder.decrementAndIndent();
    stringBuilder.appendAndIndent("}");      
    
    stringBuilder.decrementAndIndent();
    stringBuilder.appendAndIndent("}");
    stringBuilder.appendAndIndent("else {");
    stringBuilder.incrementAndIndent();
    stringBuilder.appendAndIndent("MPI_Request* sendRequestHandle = new MPI_Request();");
		stringBuilder.appendAndIndent("MPI_Status   status;");
		stringBuilder.appendAndIndent("int          flag = 0;");
		stringBuilder.appendAndIndent("int          result;");
		stringBuilder.indent();
		stringBuilder.appendAndIndent("clock_t      timeOutWarning   = -1;");
		stringBuilder.appendAndIndent("clock_t      timeOutShutdown  = -1;");
		stringBuilder.appendAndIndent("bool         triggeredTimeoutWarning = false;");
		stringBuilder.indent();   
		
		stringBuilder.append("if (exchangeOnlyAttributesMarkedWithParallelise) {");
		stringBuilder.incrementAndIndent();
		stringBuilder.append("result = MPI_Isend(");
		stringBuilder.incrementAndIndent();
		stringBuilder.appendAndIndent("this, 1, Datatype, destination,");
		stringBuilder.appendAndIndent("tag, tarch::parallel::Node::getInstance().getCommunicator(),");
		stringBuilder.append("sendRequestHandle");
		stringBuilder.decrementAndIndent();
		stringBuilder.appendAndIndent(");");
		stringBuilder.decrementAndIndent();
		stringBuilder.appendAndIndent("}");
		stringBuilder.append("else {");
		stringBuilder.incrementAndIndent();
		stringBuilder.append("result = MPI_Isend(");
		stringBuilder.incrementAndIndent();
		stringBuilder.appendAndIndent("this, 1, FullDatatype, destination,");
		stringBuilder.appendAndIndent("tag, tarch::parallel::Node::getInstance().getCommunicator(),");
		stringBuilder.append("sendRequestHandle");
		stringBuilder.decrementAndIndent();
		stringBuilder.appendAndIndent(");");
		stringBuilder.decrementAndIndent();
		stringBuilder.appendAndIndent("}");
		
		stringBuilder.append("if  (result!=MPI_SUCCESS) {");
		stringBuilder.incrementAndIndent();
		stringBuilder.appendAndIndent("std::ostringstream msg;");
		stringBuilder.appendAndIndent("msg << \"was not able to send message "+className+" \"");
		stringBuilder.appendAndIndent("<< toString()");
		stringBuilder.appendAndIndent("<< \" to node \" << destination");
		stringBuilder.appendAndIndent("<< \": \" << tarch::parallel::MPIReturnValueToString(result);");
		stringBuilder.append("_log.error( \"send(int)\",msg.str() );");
		stringBuilder.decrementAndIndent();
		stringBuilder.appendAndIndent("}");  

		stringBuilder.appendAndIndent("result = MPI_Test( sendRequestHandle, &flag, &status );");
		stringBuilder.append("while (!flag) {");
		stringBuilder.incrementAndIndent();

		stringBuilder.appendAndIndent("if (timeOutWarning==-1)   timeOutWarning   = tarch::parallel::Node::getInstance().getDeadlockWarningTimeStamp();");
		stringBuilder.appendAndIndent("if (timeOutShutdown==-1)  timeOutShutdown  = tarch::parallel::Node::getInstance().getDeadlockTimeOutTimeStamp();");
		
		stringBuilder.appendAndIndent("result = MPI_Test( sendRequestHandle, &flag, &status );");
		stringBuilder.append("if (result!=MPI_SUCCESS) {");
		stringBuilder.incrementAndIndent();
		stringBuilder.appendAndIndent("std::ostringstream msg;");
		stringBuilder.appendAndIndent("msg << \"testing for finished send task for "+className+" \"");
		stringBuilder.appendAndIndent("<< toString()");  
		stringBuilder.appendAndIndent("<< \" sent to node \" << destination");
		stringBuilder.appendAndIndent("<< \" failed: \" << tarch::parallel::MPIReturnValueToString(result);");
		stringBuilder.append("_log.error(\"send(int)\", msg.str() );");
		stringBuilder.decrementAndIndent();
		stringBuilder.appendAndIndent("}");
		stringBuilder.indent();
		stringBuilder.appendAndIndent("// deadlock aspect");
		stringBuilder.append("if (");
		stringBuilder.incrementAndIndent();
		stringBuilder.appendAndIndent("tarch::parallel::Node::getInstance().isTimeOutWarningEnabled() &&"); 
		stringBuilder.appendAndIndent("(clock()>timeOutWarning) &&"); 
		stringBuilder.append("(!triggeredTimeoutWarning)");
		stringBuilder.decrementAndIndent();
		stringBuilder.append(") {");
		stringBuilder.incrementAndIndent();
		stringBuilder.appendAndIndent("tarch::parallel::Node::getInstance().writeTimeOutWarning("); 
		stringBuilder.appendAndIndent("\""+className+"\","); 
		stringBuilder.appendAndIndent("\"send(int)\", destination,tag,1"); 
		stringBuilder.appendAndIndent(");");
		stringBuilder.append("triggeredTimeoutWarning = true;");
		stringBuilder.decrementAndIndent();
		stringBuilder.appendAndIndent("}");
		stringBuilder.append("if (");
		stringBuilder.incrementAndIndent();     
		stringBuilder.appendAndIndent("tarch::parallel::Node::getInstance().isTimeOutDeadlockEnabled() &&"); 
		stringBuilder.append("(clock()>timeOutShutdown)");
		stringBuilder.decrementAndIndent();
		stringBuilder.append(") {");
		stringBuilder.incrementAndIndent();
		stringBuilder.appendAndIndent("tarch::parallel::Node::getInstance().triggerDeadlockTimeOut("); 
		stringBuilder.appendAndIndent("\""+className+"\","); 
		stringBuilder.appendAndIndent("\"send(int)\", destination,tag,1"); 
		stringBuilder.append(");");
		stringBuilder.decrementAndIndent();
		stringBuilder.appendAndIndent("}");
		
		stringBuilder.appendAndIndent("tarch::parallel::Node::getInstance().receiveDanglingMessages();");
		stringBuilder.appendAndIndent("usleep(communicateSleep);");
		
		stringBuilder.decrementAndIndent();
		stringBuilder.appendAndIndent("}");
		stringBuilder.indent();
		stringBuilder.appendAndIndent("delete sendRequestHandle;");
		stringBuilder.appendAndIndent("#ifdef Debug");
		stringBuilder.appendAndIndent("_log.debug(\"send(int,int)\", \"sent \" + toString() );");
		stringBuilder.appendAndIndent("#endif");
    stringBuilder.decrementAndIndent();
    stringBuilder.appendAndIndent("}");
    stringBuilder.decrementAndIndent();
    stringBuilder.appendAndIndent("}");

		stringBuilder.indent(3);
	}
	
	private void generateReceiveMethod(DaStStringBuilder stringBuilder, String className) {
		// Receive Operation
		
		stringBuilder.append("void "+className+"::receive(int source, int tag, bool exchangeOnlyAttributesMarkedWithParallelise, int communicateSleep) {");
    stringBuilder.incrementAndIndent();
    stringBuilder.appendAndIndent("if (communicateSleep<0) {");
    stringBuilder.incrementAndIndent();
    stringBuilder.appendAndIndent("MPI_Status  status;");
    stringBuilder.appendAndIndent("const int   result = MPI_Recv(this, 1, exchangeOnlyAttributesMarkedWithParallelise ? Datatype : FullDatatype, source, tag, tarch::parallel::Node::getInstance().getCommunicator(), &status);");

    stringBuilder.append("if ( result != MPI_SUCCESS ) {");
    stringBuilder.incrementAndIndent();
    stringBuilder.appendAndIndent("std::ostringstream msg;");
    stringBuilder.appendAndIndent("msg << \"failed to start to receive "+className+" from node \""); 
    stringBuilder.appendAndIndent("<< source << \": \" << tarch::parallel::MPIReturnValueToString(result);");
    stringBuilder.append("_log.error( \"receive(int)\", msg.str() );");
    stringBuilder.decrementAndIndent();
    stringBuilder.appendAndIndent("}");
    stringBuilder.decrementAndIndent();
    stringBuilder.appendAndIndent("}");
    stringBuilder.appendAndIndent("else {");
    stringBuilder.incrementAndIndent();

    stringBuilder.appendAndIndent("MPI_Request* sendRequestHandle = new MPI_Request();");
		stringBuilder.appendAndIndent("MPI_Status   status;");
		stringBuilder.appendAndIndent("int          flag = 0;");
		stringBuilder.appendAndIndent("int          result;");
		stringBuilder.indent();
		stringBuilder.appendAndIndent("clock_t      timeOutWarning   = -1;");
		stringBuilder.appendAndIndent("clock_t      timeOutShutdown  = -1;");
		stringBuilder.appendAndIndent("bool         triggeredTimeoutWarning = false;");
		stringBuilder.indent();
		
		stringBuilder.append("if (exchangeOnlyAttributesMarkedWithParallelise) {");
		stringBuilder.incrementAndIndent();
		stringBuilder.append("result = MPI_Irecv(");
		stringBuilder.incrementAndIndent();
		stringBuilder.appendAndIndent("this, 1, Datatype, source, tag,"); 
		stringBuilder.append("tarch::parallel::Node::getInstance().getCommunicator(), sendRequestHandle");
		stringBuilder.decrementAndIndent();
		stringBuilder.appendAndIndent(");");
		stringBuilder.decrementAndIndent();
		stringBuilder.appendAndIndent("}");
		stringBuilder.append("else {");
		stringBuilder.incrementAndIndent();
		stringBuilder.append("result = MPI_Irecv(");
		stringBuilder.incrementAndIndent();
		stringBuilder.appendAndIndent("this, 1, FullDatatype, source, tag,"); 
		stringBuilder.append("tarch::parallel::Node::getInstance().getCommunicator(), sendRequestHandle");
		stringBuilder.decrementAndIndent();
		stringBuilder.appendAndIndent(");");
		stringBuilder.decrementAndIndent();
		stringBuilder.appendAndIndent("}");
		
		stringBuilder.append("if ( result != MPI_SUCCESS ) {");
		stringBuilder.incrementAndIndent();
		stringBuilder.appendAndIndent("std::ostringstream msg;");
		stringBuilder.appendAndIndent("msg << \"failed to start to receive "+className+" from node \""); 
		stringBuilder.appendAndIndent("<< source << \": \" << tarch::parallel::MPIReturnValueToString(result);");
		stringBuilder.append("_log.error( \"receive(int)\", msg.str() );");
		stringBuilder.decrementAndIndent();
		stringBuilder.appendAndIndent("}");
		stringBuilder.indent();
		
		stringBuilder.appendAndIndent("result = MPI_Test( sendRequestHandle, &flag, &status );");
		stringBuilder.append("while (!flag) {");
		stringBuilder.incrementAndIndent();
		
		stringBuilder.appendAndIndent("if (timeOutWarning==-1)   timeOutWarning   = tarch::parallel::Node::getInstance().getDeadlockWarningTimeStamp();");
		stringBuilder.appendAndIndent("if (timeOutShutdown==-1)  timeOutShutdown  = tarch::parallel::Node::getInstance().getDeadlockTimeOutTimeStamp();");
		
		stringBuilder.appendAndIndent("result = MPI_Test( sendRequestHandle, &flag, &status );");
		stringBuilder.append("if (result!=MPI_SUCCESS) {");
		stringBuilder.incrementAndIndent();
		stringBuilder.appendAndIndent("std::ostringstream msg;");
		stringBuilder.appendAndIndent("msg << \"testing for finished receive task for "+className+" failed: \""); 
		stringBuilder.appendAndIndent("<< tarch::parallel::MPIReturnValueToString(result);");
		stringBuilder.append("_log.error(\"receive(int)\", msg.str() );");
		stringBuilder.decrementAndIndent();
		stringBuilder.appendAndIndent("}");
		stringBuilder.indent();
		stringBuilder.appendAndIndent("// deadlock aspect");
		stringBuilder.append("if (");
	stringBuilder.incrementAndIndent();
	stringBuilder.appendAndIndent("tarch::parallel::Node::getInstance().isTimeOutWarningEnabled() &&"); 
	stringBuilder.appendAndIndent("(clock()>timeOutWarning) &&"); 
	stringBuilder.append("(!triggeredTimeoutWarning)");
	stringBuilder.decrementAndIndent();
	stringBuilder.append(") {");
	stringBuilder.incrementAndIndent();
	stringBuilder.appendAndIndent("tarch::parallel::Node::getInstance().writeTimeOutWarning("); 
	stringBuilder.appendAndIndent("\""+className+"\","); 
	stringBuilder.appendAndIndent("\"receive(int)\", source,tag,1"); 
	stringBuilder.appendAndIndent(");");
	stringBuilder.append("triggeredTimeoutWarning = true;");
	stringBuilder.decrementAndIndent();
	stringBuilder.appendAndIndent("}");
		stringBuilder.append("if (");
		stringBuilder.incrementAndIndent();	    
		stringBuilder.appendAndIndent("tarch::parallel::Node::getInstance().isTimeOutDeadlockEnabled() &&"); 
		stringBuilder.append("(clock()>timeOutShutdown)");
		stringBuilder.decrementAndIndent();
		stringBuilder.append(") {");
		stringBuilder.incrementAndIndent();
		stringBuilder.appendAndIndent("tarch::parallel::Node::getInstance().triggerDeadlockTimeOut("); 
		stringBuilder.appendAndIndent("\""+className+"\","); 
		stringBuilder.appendAndIndent("\"receive(int)\", source,tag,1"); 
		stringBuilder.append(");");
		stringBuilder.decrementAndIndent();
		stringBuilder.appendAndIndent("}");
		
		stringBuilder.appendAndIndent("tarch::parallel::Node::getInstance().receiveDanglingMessages();");
		stringBuilder.appendAndIndent("usleep(communicateSleep);");

		stringBuilder.decrementAndIndent();
		stringBuilder.appendAndIndent("}");
		stringBuilder.indent();
		stringBuilder.appendAndIndent("delete sendRequestHandle;");
		stringBuilder.indent();
		stringBuilder.appendAndIndent("#ifdef Debug");
		stringBuilder.appendAndIndent("_log.debug(\"receive(int,int)\", \"received \" + toString() ); ");
		stringBuilder.appendAndIndent("#endif");
		stringBuilder.decrementAndIndent();	  
		stringBuilder.appendAndIndent("}");
    stringBuilder.decrementAndIndent();
    stringBuilder.appendAndIndent("}");
		
		stringBuilder.indent(3);
		
	} 
	
	private void generateIsMessageInQueueMethod(DaStStringBuilder stringBuilder, String className) {

		stringBuilder.append("bool "+className+"::isMessageInQueue(int tag, bool exchangeOnlyAttributesMarkedWithParallelise) {");
		stringBuilder.incrementAndIndent();
		stringBuilder.appendAndIndent("MPI_Status status;");
		stringBuilder.appendAndIndent("int  flag        = 0;");
		stringBuilder.append("MPI_Iprobe(");
		stringBuilder.incrementAndIndent();
		stringBuilder.appendAndIndent("MPI_ANY_SOURCE, tag,"); 
		stringBuilder.append("tarch::parallel::Node::getInstance().getCommunicator(), &flag, &status");
		stringBuilder.decrementAndIndent();
		stringBuilder.appendAndIndent(");");
		
		
		//stringBuilder.append("return flag != 0;");
		stringBuilder.append("if (flag) {");
		stringBuilder.incrementAndIndent();
		stringBuilder.appendAndIndent("int  messageCounter;");
		stringBuilder.append("if (exchangeOnlyAttributesMarkedWithParallelise) {");
		stringBuilder.incrementAndIndent();
		stringBuilder.append("MPI_Get_count(&status, Datatype, &messageCounter);");
		stringBuilder.decrementAndIndent();
		stringBuilder.appendAndIndent("}");
		stringBuilder.append("else {");
		stringBuilder.incrementAndIndent();
		stringBuilder.append("MPI_Get_count(&status, FullDatatype, &messageCounter);");
		stringBuilder.decrementAndIndent();
		stringBuilder.appendAndIndent("}");
		
		stringBuilder.append("return messageCounter > 0;");
		stringBuilder.decrementAndIndent();
		stringBuilder.appendAndIndent("}");
		stringBuilder.appendAndIndent("else return false;"); 
		
		stringBuilder.decrementAndIndent();
		stringBuilder.appendAndIndent("}");
		stringBuilder.indent();
	}
}
