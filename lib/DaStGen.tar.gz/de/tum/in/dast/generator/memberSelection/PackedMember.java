// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.memberSelection;

import de.tum.in.dast.generator.DastGenAST.Size;
import de.tum.in.dast.generator.DastGenAST.Type;
import de.tum.in.dast.generator.mapper.MapperFactory;

public class PackedMember extends Member {

	// the startIndex of this member in a bitfield
	protected String startIndex = null;
	// the start of the range of values of this member.
	protected int rangeStart = 0;
	// the start of the range of values of this member.
	protected int rangeEnd = 0;
	
	// the type, to which packed members are mapped.
	// static, because it is the same for all members
	protected String bitFieldType;
	
	public PackedMember(String memberName, String type) {
		super(memberName, type);
	}
	
	public PackedMember clone() {
		PackedMember retVal = new PackedMember(this.memberName, this.type);
		retVal.mappedVariable = new String(this.mappedVariable);
		retVal.className = new String(this.className);
		retVal.persistent = this.persistent;
		retVal.arraySize = this.arraySize;
		retVal.isParallel = this.isParallel;
		retVal.bitFieldType = this.bitFieldType;
		
		retVal.startIndex = this.startIndex;
		retVal.rangeStart = this.rangeStart;
		retVal.rangeEnd = this.rangeEnd;
				
		// TODO it's not right to assign mappers instead of cloning! 
		retVal.mapper = MapperFactory.getInstance().getMapperForMember(retVal, this.mapper.getTypeObject());
		
		return retVal;
	}
	
	@Override
	public boolean isPacked() {
		return MapperFactory.getSupportPackedTypes();
	}

	
	public void setBitFieldType(String packedType) {
		bitFieldType = packedType;
	}
	
	public Size getBitfieldLength() {
		return mapper.getBitfieldLength();
	}


	public String getStartIndex() {
		return startIndex;
	}


	public void setStartIndex(String startIndex) {
		this.startIndex = startIndex;
	}
	
	/**
	 * @return the type of the bitfield, 
	 * where all members except the doubles are packed into.
	 */
	public String getBitFieldType() {
		return bitFieldType;
	}
	
	/**
	 * To make the generated DaStGen code pass a strict type checking in C++, 
	 * you often have to embed operations into casts, as bit-wise operations 
	 * often return solely integers. This operation gives you something like
	 * 
	 * \code
	 * static_cast<bitfield-type>
	 * \endcode
	 * 
	 * i.e. you still have to add your brackets manually.
	 * 
	 * @return
	 */
	public String getBitFieldCast() {
		return "static_cast<" + getBitFieldType() + ">";
	}
	
	/**
	 * @return the packed type of this member
	 */
	public String getPackedType()
	{
		if (Type.DOUBLE.equals(this.type))
		{
			return "short int";		
		} else {
			return bitFieldType;
		}
	}


	public int getRangeStart() {
		return rangeStart;
	}


	public void setRangeStart(int rangeStart) {
		this.rangeStart = rangeStart;
	}


	public int getRangeEnd() {
		return rangeEnd;
	}


	public void setRangeEnd(int rangeEnd) {
		this.rangeEnd = rangeEnd;
	}
	
	public String toString() {
		return super.toString() + " RangeStart: " + rangeStart + " RangeEnd: " + rangeEnd + " startIndex: " + startIndex; 
	}

	@Override
	public int hashCode() {
		final int PRIME = 31;
		int result = super.hashCode();
		result = startIndex != null ? (PRIME * result + startIndex.hashCode()) : result;
		result = PRIME * result + rangeStart;
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		final PackedMember other = (PackedMember) obj;
		if (rangeStart != other.rangeStart)
			return false;
		if (startIndex != other.startIndex)
			return false;
		
		return true;
	}

}
