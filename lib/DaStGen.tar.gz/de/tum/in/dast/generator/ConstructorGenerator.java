// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import de.tum.in.dast.generator.DastGenAST.DaStGenASTBuilder;
import de.tum.in.dast.generator.DastGenAST.Type;
import de.tum.in.dast.generator.memberSelection.Member;
import de.tum.in.dast.generator.memberSelection.PackedMember;
import de.tum.in.dast.generator.naming.NameTranslator;
import de.tum.in.dast.generator.naming.NameTranslatorFactory;
import de.tum.in.dast.util.DaStStringBuilder;

/**
 * As the constructors grow increasingly complex, this is a 
 * class dedicated to constructor generation.
 * 
 * @author Wolfgang Eckhardt
 *
 */
public class ConstructorGenerator {

	/** the simple classname of the class */
	private String simpleClassName;
	
	/** the qualified classname of the class being declared*/
	private String qualifiedClassName;
	
	/** the members which should be initialized */
	private List<Member> members;
	
	/** members for which assertions have to be generated */
	private List<Member> assertionMembers;
	
	private NameTranslator naming = NameTranslatorFactory.getNameTranslator();

	/**
	 * 
	 */
	public ConstructorGenerator(String namespace, String className, List<Member> members, List<Member> assertionMembers) {
		this.simpleClassName = className;
		this.members = members;
		this.assertionMembers = assertionMembers;
		if (! "".equals(namespace)) {
			qualifiedClassName = namespace + "::" + simpleClassName;
		} else {
			qualifiedClassName = simpleClassName;
		}
	}
	
	/**
	 * Basically, generates 2 constructors for a class, that means:
	 * - a default constructor (empty constructor)
	 * - a constructor, which takes all members
	 *   
	 * The flag hasPersistentMembers decides, if the class has a nested struct
	 * PersistentRecords. Then additionally a constructor, which takes the struct persistent records,
	 * is generated as well a constructor, which takes the individual members of the struct (if it is not empty!)
	 * 
	 * @param implementation
	 * @param header
	 * @param hasPersistentMembers if true, 2 additional constructors which initialize the nested struct only are generated
	 */
	public void generateConstructors(DaStStringBuilder implementation, DaStStringBuilder header, boolean hasPersistentMembers) {
		List<Member> initDataTypeMembers = getInitDataTypeMembers(members, !hasPersistentMembers);
		List<Member> initMembers = new ArrayList<Member>(members);
		List<Member> persistentMembers = getPersistentMembers(members);

		if (hasPersistentMembers) {
			initDataTypeMembers.removeAll(persistentMembers);
			initMembers.removeAll(persistentMembers);
		}
		
		List<Member> packedMembers = getPackedMembers(initMembers);
		initMembers.removeAll(packedMembers);

		generateEmptyConstructor(implementation, header, initDataTypeMembers);
		
		if (hasPersistentMembers) {
			// generate the constructor which takes a struct persistentRecords as argument
			String persistentRecordsDataType = naming.getPersistentRecords();
			String persistentRecordsAttribute = naming.getAttributeName(DaStGenASTBuilder.FIELD_PERSISTENT_RECORDS);
			generateConstructorSignature(header, persistentRecordsDataType, persistentRecordsAttribute, false);
			header.append(";");
			header.indent(2);
			generateConstructorSignature(implementation, persistentRecordsDataType, persistentRecordsAttribute, true);
			
			String persistentRecordsArgument = naming.getArgumentName(DaStGenASTBuilder.FIELD_PERSISTENT_RECORDS);
			implementation.appendAndIndent(":");
			generatePersistentRecordsConstructorCall(implementation, persistentMembers, persistentRecordsArgument);

			generateDataTypeInitList(implementation, initDataTypeMembers);

			implementation.append(" {");
			implementation.incrementAndIndent(getClass().getName());
			appendAssertions(implementation);
			implementation.decrementAndIndent(getClass().getName());
			implementation.appendAndIndent("}");
			implementation.indent(2);
		}
		
		if (this.members.isEmpty()) {
			// don't generate if there are no members 
			return;
		}
		
		if (hasPersistentMembers && !persistentMembers.isEmpty()) {
			
			// constructor which takes all persistent attributes
			generateConstructorSignature(header, persistentMembers, false);
			header.append(";");
			header.indent(2);
			generateConstructorSignature(implementation, persistentMembers, true);
			
			implementation.appendAndIndent(":");
			generatePersistentRecordsConstructorCall(implementation, persistentMembers, "");

			generateDataTypeInitList(implementation, initDataTypeMembers);

			implementation.append(" {");
			implementation.incrementAndIndent(getClass().getName());
			appendAssertions(implementation);
			implementation.decrementAndIndent(getClass().getName());
			implementation.appendAndIndent("}");
			implementation.indent(2);
			
			if (!initMembers.isEmpty() || !packedMembers.isEmpty()) {
				// The full constructor considering packed records constructor call, init-list and setter()
				generateFullConstructor(implementation, header, persistentMembers, packedMembers, initMembers);
			}
		} else {
			generateFullConstructor(implementation, header, null, packedMembers, initMembers);
		}
	}
	
	// protected for testing purpose
	protected void generateEmptyConstructor(DaStStringBuilder implementation, DaStStringBuilder header, List<Member> initDataTypeMembers) {
		generateConstructorSignature(header, new ArrayList<Member>(), false);
		header.append(";");
		header.indent(2);
		generateConstructorSignature(implementation, new ArrayList<Member>(), true);
		if (!initDataTypeMembers.isEmpty()) {
			implementation.appendAndIndent(":");
			generateDataTypeInitList(implementation, initDataTypeMembers);
		}
		implementation.append(" {");
		implementation.incrementAndIndent(getClass().getName());
		appendAssertions(implementation);
		implementation.decrementAndIndent(getClass().getName());
		implementation.appendAndIndent("}");
		implementation.indent(2);
	}
	
	/**
	 * Creates the full constructor, i.e. the one with the whole argument list. 
	 * 
	 * @param persistentMembers members, which have to be part of the constructor call of struct PersistentRecords
	 * @param packedMembers members for which the set-Method has to be called because they are packed
	 * @param initMembers members which can be part of the initializer-list
	 */
	protected void generateFullConstructor(DaStStringBuilder implementation, DaStStringBuilder header,
			List<Member> persistentMembers, List<Member> packedMembers,	List<Member> initMembers) {
		
		generateConstructorSignature(header, members, false);
		header.append(";");
		header.indent(2);
		generateConstructorSignature(implementation, members, true);
		if (persistentMembers != null || !initMembers.isEmpty()) {
			implementation.appendAndIndent(":");
		}
		
		if (persistentMembers != null) {
			generatePersistentRecordsConstructorCall(implementation, persistentMembers, "");
			if (!initMembers.isEmpty()) {
				implementation.append(",");
			}
		}
		
		if (!initMembers.isEmpty()) {
			generateInitList(implementation, initMembers, "");
		}
		implementation.append(" {");
		implementation.incrementAndIndent(getClass().getName());
		generateSetterList(implementation, packedMembers, "");
		appendAssertions(implementation);
		implementation.decrementAndIndent(getClass().getName());
		implementation.append("}");
		implementation.indent(2);
		
	}
	
	/**
	 * Generate the constructor signature for a constructor, which takes
	 * an argument list of the members to initialize.
	 * 
	 * N.B. its only the signature created, without trailing ";" or "{" etc.
	 * 
	 * @param qualified does the Signature have to be qualified	 
	 */
	public void generateConstructorSignature(DaStStringBuilder builder, List<Member> argumentMembers, boolean qualified) {
		
		if (qualified) {
			builder.append(qualifiedClassName + "::");
		} else {
			// if not qualified: we write the declaration, so add the comment
			MethodGenerator.writeMethodComment(builder);
		}
		
		builder.append(simpleClassName+"(");
		Iterator<Member> iterator = argumentMembers.iterator();
		while (iterator.hasNext()) {
			Member member = iterator.next();
			builder.append("const "+member.getMappedType() + "& " + 
					naming.getArgumentName(member.getMemberName()));
			if (iterator.hasNext()) {
				builder.append(", ");
			}
		}
		
		builder.append(")");
	}
	
	/**
	 * Generate the constructor signature for a constructor, which takes
	 * as argument a class, i.e. this operation writes the copy constructor.
	 * 
	 * @param parameterType the classname
	 * @param parameterName the argument name of the class
	 * @param qualified does the Signature have to be qualified	 
	 */
	public void generateConstructorSignature(DaStStringBuilder builder, String parameterType, String parameterName, boolean qualified) {

		if (qualified) {
			builder.append(qualifiedClassName + "::");
		} else {
			// if not qualified: we write the declaration, so add the comment
			MethodGenerator.writeMethodComment(builder);
		}
			
		builder.append(simpleClassName + "(const " + parameterType + "& " + 
				naming.getArgumentName(parameterName) + ")");
	}
	

	private void appendAssertions(DaStStringBuilder builder) {
		for (Member m: assertionMembers) {
			m.writeConstructorAsserts(builder);
		}
	}
	
	
	/**
	 * Generate the initialization list for usual members, except nested struct persistent records
	 * 
	 * @param prefix the prefix for accessing the value to set
	 * @param nestedPersistentRecords indicating, if persistent members are nested in a 
	 * 			struct persistentRecords
	 */
	private void generateInitList(DaStStringBuilder builder, List<Member> members, String prefix) {
		Iterator<Member> iter = members.iterator();
		while (iter.hasNext()) {
			Member member = iter.next();
			String getter = getGetExpression(member, prefix);

      String expression;
      expression = naming.getAttributeName(member.getMemberName()) + "("+getter+")";
	    builder.append(expression);

			if (iter.hasNext()) {
				builder.appendAndIndent(",");
			}
		}
	}
	
	
	private void generateDataTypeInitList(DaStStringBuilder builder, List<Member> members) {
		Iterator<Member> iter = members.iterator();
		while (iter.hasNext()) {
			Member member = iter.next();
			Type dataType = member.getMapper().getTypeObject();
			String init = dataType.getInitialization(member.getMappedVariable());
			builder.append(init);
			if (iter.hasNext()) {
				builder.appendAndIndent(",");
			}
		}
	}
	
	
	/**initialization 
	 * gererate the list of set-Methods for the members, if necessary
	 * 
	 * @param prefix the prefix for accessing the value to set
	 * @param nestedPersistentRecords indicating, if persistent members are nested in a 
	 * 			struct persistentRecords
	 */
	private void generateSetterList(DaStStringBuilder builder, List<Member> members, String prefix) {
		ListIterator<Member> iterator = members.listIterator();
		while (iterator.hasNext()) {
			Member member = iterator.next();
			String getter = getGetExpression(member, prefix);
			String expression = naming.getSetter(member.getMemberName()) + "("+getter+")";
			builder.appendAndIndent(expression + ";");
		}
	}
	
	
	/**
	 * Generate a constructor call to the field "persistentRecords". This one 
	 * is required by the other constructors that initialise on the one hand 
	 * their own fields, on the other hand, they have to initialise the subclass
	 * PersistentRecords.
	 * 
	 * @param members the persistent members 
	 * @param method how to access the arguments
	 * @param prefix prefix to qualify or dereference
	 */
	// package visibility for testing purpose
	public void generatePersistentRecordsConstructorCall(DaStStringBuilder builder, List<Member> members, String prefix) {
		builder.append(naming.getAttributeName(DaStGenASTBuilder.FIELD_PERSISTENT_RECORDS + "("));
		
		ListIterator<Member> iterator = members.listIterator();
		while (iterator.hasNext()) {
			Member member = iterator.next();
			String getter = getGetExpression(member, prefix);
			builder.append(getter);
			if (iterator.hasNext()) {
				builder.append(", ");
			}
		}
		builder.append(")");
	}
	
	
	/**
	 * Create a get expression. It is used by the constructors, e.g., to create 
	 * the copy constructor and the partial copy constructors (persistent records 
	 * into whole class, e.g.).
	 * 
	 * @param member
	 * @param prefix
	 * @return
	 */
	private String getGetExpression(Member member, String prefix) {
		String getter;
    if (member.isPacked() && !"".equals(prefix)) { 
			getter =  prefix + "."+ naming.getGetter(member.getMemberName()+"()");
		} else if ("".equals(prefix)) {
			getter = naming.getArgumentName(member.getMemberName());
		} else {
			getter =  prefix + "." + naming.getAttributeName(member.getMemberName());
		}
		return getter;
	}

	
	
	/**
	 * Utility method to extract the persistent members
	 */
	private List<Member> getPersistentMembers(List<Member> members) {
		ArrayList<Member> persistentMembers = new ArrayList<Member>();
		
		ListIterator<Member> iterator = members.listIterator();
		while(iterator.hasNext()) {
			Member member = iterator.next();
			if (member.isPersistent()) {
				persistentMembers.add(member);
			}
		}
		
		return persistentMembers;
	}
	
	/**
	 * Utility method to extract the packed members
	 */
	private List<Member> getPackedMembers(List<Member> members) {
		ArrayList<Member> packedMembers = new ArrayList<Member>();
		
		ListIterator<Member> iterator = members.listIterator();
		while(iterator.hasNext()) {
			Member member = iterator.next();
			if (member.isPacked()) {
				packedMembers.add(member);
			}
		}
		
		return packedMembers;
	}

	/**
	 * Utility method to extract the members, which are of a datatype (e.g. std::vector),
	 * which needs to be initialized.
	 * 
	 * @param ignorePersistent if true, persistent members are not contained in the list returned. 
	 */
	private List<Member> getInitDataTypeMembers(List<Member> members, boolean ignorePersistence) {
		ArrayList<Member> initMembers = new ArrayList<Member>();
		
		ListIterator<Member> iterator = members.listIterator();
		while(iterator.hasNext()) {
			Member member = iterator.next();
			Type dataType = member.getMapper().getTypeObject();
			boolean needsInitialization = dataType.needsInitialization();
			boolean notPersistent = !member.isPersistent() || ignorePersistence;
			boolean isPacked = member.isPacked() 
				&& !"0".equals(((PackedMember)member).getBitfieldLength().getStringRepresentation());
			if (needsInitialization && notPersistent && !isPacked) {
				initMembers.add(member);
			}
		}
		
		return initMembers;
	}
	
}
