// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.mapper;

import de.tum.in.dast.generator.DaStConfiguration;
import de.tum.in.dast.generator.DastGenAST.Size;
import de.tum.in.dast.generator.DastGenAST.Type;
import de.tum.in.dast.generator.memberSelection.Member;
import de.tum.in.dast.generator.naming.NameTranslator;
import de.tum.in.dast.generator.naming.NameTranslatorFactory;
import de.tum.in.dast.util.DaStStringBuilder;

/**
 * Simple Mapper 1:1
 * 
 * Two operations are generated: A getter and a setter.
 * 
 * @author Wolfgang Eckhardt, Tobias Weinzierl
 */
public class SimpleMapper implements Mapper {
	
	protected Member member;
	protected NameTranslator translator = NameTranslatorFactory.getNameTranslator();
	protected Type type;
	
	public SimpleMapper(Member member, Type type) {
		this.member = member;
		this.type = type;
	}
	
	public int getNumberOfOperations() {
	  return 2;
	}
	
	public void writeMethodSignature(int operationNumber, DaStStringBuilder builder) {
	  switch (operationNumber) {
	    case 0:
  			writeMethodComment(builder);
      	builder.append( getGetMethodSignature(false) );
	    	builder.append( ";" );
	    	break;
	    case 1:
	  		writeMethodComment(builder);
      	builder.append( getSetMethodSignature(member,false) );
	    	builder.append( ";" );
	    	break;
	    default: throw new RuntimeException( "Only operation 0 and 1 supported" );
	  }
	}
	
	public void writeMethodImplementation(int operationNumber, DaStStringBuilder builder) {
	  switch (operationNumber) {
	    case 0:
	    	getGetMethod(builder);
	    	break;
	    case 1:
	    	getSetMethod(builder);
	    	break;
	    default: throw new RuntimeException( "Only operation 0 and 1 supported" );
	  }
	}
	
	private void getGetMethod(DaStStringBuilder builder) {
		builder.indent();
		builder.append(getGetMethodSignature(!DaStConfiguration.manuallyInline));
        builder.append(" {");
        builder.incrementAndIndent(getClass().getName());
        builder.append(getGetMethodBody(member));
        builder.decrementAndIndent(getClass().getName());
		builder.appendAndIndent("}");
	}

	private String getGetMethodSignature(boolean qualified) {
    String prefix             = "";
    String qualifiedClassName = "";
    String attributes         = "";
		String memberType = type.getTypeString(qualified);
    if (DaStConfiguration.manuallyInline) {
      prefix += "inline";
    }
		if (qualified) {
			qualifiedClassName = member.getClassName() + "::";
		} 
    if (DaStConfiguration.manuallyInline) {
      attributes += AttributeInline;
    }
		return prefix + " "  + memberType + " " + qualifiedClassName +
						translator.getGetter(member.getMemberName())+"() const " + attributes;
	}
	
	protected String getGetMethodBody(Member member) {
		return "return "+member.getMappedVariable()+";";
	}

	private void getSetMethod(DaStStringBuilder builder) {
		builder.indent();
		builder.append(getSetMethodSignature(member, !DaStConfiguration.manuallyInline) + " {");
		builder.incrementAndIndent(getClass().getName());
        builder.append(getSetMethodBody(member));
        builder.decrementAndIndent(getClass().getName());
		builder.appendAndIndent("}");
	}

	private String getSetMethodSignature(Member member, boolean qualified) {
    String prefix             = "";
    String qualifiedClassName = "";
    String attributes         = "";
    if (DaStConfiguration.manuallyInline) {
      prefix += "inline";
    }
		if (qualified) {
			qualifiedClassName = member.getClassName() + "::";
		}
    if (DaStConfiguration.manuallyInline) {
      attributes += AttributeInline;
    }
		return prefix + " void " + qualifiedClassName + 
			translator.getSetter(member.getMemberName()) + 
			"(const "+type.getTypeString(false)+"& "+
			translator.getArgumentName(member.getMemberName())+") " + attributes;
	}
	
	protected String getSetMethodBody(Member member) {
		return member.getMappedVariable()+" = " +
		translator.getArgumentName(member.getMemberName()) + ";";
	}


//	@Override java 1.5 doesn't accept override annotation for interfaces
	public void writeDeclaration(DaStStringBuilder builder, boolean currentClassIsPacked) {
		builder.appendAndIndent(member.getType()+ " "
				+translator.getAttributeName(member.getMemberName()+";"));
	}
	
	public String getMappedDataType() {
		return member.getType();
	}

	public String getToString() {
		String result = "out << \""+member.getMemberName()+":\" << ";
		if (Type.isEnum(member.getType())) {
			result += "toString("+translator.getGetter(member.getMemberName())+"());";
		} else {
			result += translator.getGetter(member.getMemberName())+"();";
		}
		
		return result;
	}
	
	/**
	 * @return "0". This mapper doesn't support the 
	 * 			compression of members, so they don't 
	 * 			need space in a bitfield
	 */
	public Size getBitfieldLength() {
		return new Size(0);
	}
	
	public Type getTypeObject() {
		return type;
	}

//	@Override java 1.5 doesn't accept override annotation for interfaces
	public void writeConstructorAssertions(DaStStringBuilder builder) {
		// No assertions to insert - do nothing.
	}


	protected void writeMethodComment(DaStStringBuilder builder) {
		builder.appendAndIndent("/**");
		builder.appendAndIndent(" * Generated");
		builder.appendAndIndent(" */");
	}
}
