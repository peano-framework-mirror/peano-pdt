// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.packing;

import java.util.ArrayList;
import java.util.List;

import de.tum.in.dast.generator.DastGenAST.Size;
import de.tum.in.dast.generator.DastGenAST.Type;
import de.tum.in.dast.generator.mapper.MapperFactory;
import de.tum.in.dast.generator.memberSelection.BitfieldMember;
import de.tum.in.dast.generator.memberSelection.Member;
import de.tum.in.dast.generator.memberSelection.PackedMember;
import de.tum.in.dast.generator.naming.NameTranslatorFactory;

/**
 * Implementation of the FirstFit-Algorithm to solve binpacking.
 * 
 * @author Wolfgang Eckhardt
 */
public class FirstFitPacker implements Packer {

	//@Override
	public void pack(List<Member> virtualMembers,
			List<Member> technicalMembers, Type packedFieldType) { 

		String packedRecords = 
			NameTranslatorFactory.getNameTranslator().getAttributeName(Packer.FIELD_PACKED_RECORDS);
		ArrayList<BitfieldMember> bitfieldMembers = new ArrayList<BitfieldMember>();

		nextMember:
			for (Member member: virtualMembers) {

				if (member.isPacked() && !Type.DOUBLE.equals(member.getType())) {


					PackedMember packedMember = (PackedMember) member;
					if ("0".equals(packedMember.getBitfieldLength().getStringRepresentation())) {
						System.err.println("XXX");
						System.err.println("XXX Warning: Member "+packedMember.getType() + " "+packedMember.getMemberName() + " declared packed without effect!");
						System.err.println("XXX");
						System.err.println("member.Mapper: " + member.getMapper().getClass());
						technicalMembers.add(packedMember);
					} else if (packedFieldType.getSize() != null && packedMember.getBitfieldLength().getSize() < 1) {
						System.err.println("XXX");
						System.err.println("XXX Warning: Member "+packedMember.getType() + " "+packedMember.getMemberName() + " declared packed without effect! " +
								"(Maybe missing attribute 'hint-value' in constant declaration?)");
						System.err.println("XXX");
						MapperFactory.setSupportPackedTypes(false);
						packedMember.setMapper(MapperFactory.getInstance().getMapperForMember(packedMember, packedMember.getMapper().getTypeObject()));
						MapperFactory.setSupportPackedTypes(true);
						technicalMembers.add(packedMember);
					} else {

						for (int i = 0; i < bitfieldMembers.size(); i++) {
							BitfieldMember bitfieldMember = bitfieldMembers.get(i);
							Size currentBitfieldSize = bitfieldMember.getBitfieldSize();
							Size newSize = currentBitfieldSize.add(packedMember.getBitfieldLength());
							if (packedFieldType.getSize() == null || newSize.lessOrEqual(packedFieldType.getSize())) {
								// add member
								bitfieldMember.setBitfieldSize(newSize);
								bitfieldMember.addMember(packedMember);
								packedMember.setMappedVariable(packedRecords+i);
								packedMember.setStartIndex(currentBitfieldSize.getStringRepresentation());
								continue nextMember;
							}
						}
						BitfieldMember field = new BitfieldMember(packedRecords+bitfieldMembers.size(), packedFieldType.getTypeString(false));
						field.setBitfieldSize(packedMember.getBitfieldLength());
						field.addMember(packedMember);
						packedMember.setStartIndex("0");
						packedMember.setMappedVariable(packedRecords+bitfieldMembers.size());
						bitfieldMembers.add(field);
					}

				} else {
					technicalMembers.add(member);
				}
			}

		technicalMembers.addAll(bitfieldMembers);

	}

}
