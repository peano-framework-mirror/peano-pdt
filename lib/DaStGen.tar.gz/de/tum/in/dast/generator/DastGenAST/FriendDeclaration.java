// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.DastGenAST;

public class FriendDeclaration implements AbstractNode {

	private String friendClass;

	public FriendDeclaration(String friend) {
		super();
		this.friendClass = friend;
	}


	public String getFriend() {
		return friendClass;
	}

	public void applyVisitor(Visitor visitor) {
		visitor.process(this);
	}

}
