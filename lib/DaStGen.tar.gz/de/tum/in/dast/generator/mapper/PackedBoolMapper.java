// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.mapper;

import de.tum.in.dast.generator.DastGenAST.Size;
import de.tum.in.dast.generator.DastGenAST.Type;
import de.tum.in.dast.generator.memberSelection.Member;
import de.tum.in.dast.generator.memberSelection.PackedMember;
import de.tum.in.dast.util.DaStStringBuilder;

/**
 * Mapper for single boolean variables. The PackedMapper could be used
 * instead, but this mapper generates a bit nicer get- and set-Methods. 
 * 
 * @author Wolfgang Eckhardt
 *
 */
public class PackedBoolMapper extends SimpleMapper {

	public PackedBoolMapper(Member member) {
		super(member, new Type(Type.BOOL, ""));
	}
	
	@Override
	public String getGetMethodBody(Member member) {
		DaStStringBuilder builder = new DaStStringBuilder();
		builder.incrementIndentLevel();
		
		// long mask = 1 << member.getStart();
		// int tmp = mappedVar & mask;
		// return (tmp != 0); 
		
		builder.appendAndIndent(((PackedMember)member).getBitFieldType()+ 
				" mask = 1 << ("+((PackedMember)member).getStartIndex()+");");
		
		builder.appendAndIndent(((PackedMember)member).getBitFieldType()+" tmp = " + ((PackedMember)member).getBitFieldCast() + "(" + 
				member.getMappedVariable() +" & mask);");
		
		builder.append("return (tmp != 0);");
		return builder.toString();
	}
	
	@Override
	public String getSetMethodBody(Member member) {
		DaStStringBuilder builder = new DaStStringBuilder();
		builder.incrementIndentLevel();
		
		String mappedVariable = ((PackedMember)member).getMappedVariable();
		builder.appendAndIndent(((PackedMember)member).getBitFieldType() + 
				" mask = 1 << ("+((PackedMember)member).getStartIndex()+");");
		
		builder.append(mappedVariable + " = " +
		        ((PackedMember)member).getBitFieldCast() + "( " +
				translator.getArgumentName(member.getMemberName())+ " ? (" +	
				mappedVariable + " | mask) : ("+mappedVariable+" & ~mask));");

		return builder.toString();	
	}
	
	/**
	 * @return "1", as boolean values just need one single bit
	 */
	@Override
	public Size getBitfieldLength() {
		return new Size(1);
	}
}
