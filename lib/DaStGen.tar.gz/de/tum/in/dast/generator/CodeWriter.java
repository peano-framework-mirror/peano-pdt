// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator;

import java.io.File;
import java.util.LinkedList;
import java.util.Set;

import de.tum.in.dast.generator.DastGenAST.MetadataSelector;
import de.tum.in.dast.generator.DastGenAST.CompilationUnit;
import de.tum.in.dast.generator.DastGenAST.DaStGenASTBuilder;
import de.tum.in.dast.generator.conditionset.Conditional;
import de.tum.in.dast.node.Start;
import de.tum.in.dast.util.DaStStringBuilder;
import de.tum.in.dast.util.FileUtilities;

/**
 * This class is the main class for code generation. It builds the DaStGenAST 
 * from given SableCC trees and applies the codegenerator to the new ast.
 * 
 * @author eckhardw
 *
 */
public class CodeWriter {

	private Set<Set<Conditional>> conditions;

	// the list of trees, read from the definition file and the extended files
	private LinkedList<Start> trees;
	
	// initialize the stringbulders to 4 kB
	private DaStStringBuilder header = new DaStStringBuilder(4096);
	private DaStStringBuilder implementation = new DaStStringBuilder(4096);
	
	private boolean runQuiet;
	
	/**
	 * Constructs a new CodeGenerator
	 * 
	 * @param trees the sableCC-syntaxtrees to generate the code from
	 */
	public CodeWriter(LinkedList<Start> trees, Set<Set<Conditional>> conditions, boolean runQuiet) {
		this.trees = trees;
		this.conditions = conditions;
		this.runQuiet = runQuiet;
	}
	
	/**
	 * Generates the code for the header and implementation file and writes it
	 * in the directory destination.
	 * 
	 * @param destination the destination directory, where header and 
	 * 			implementation file should be generated.
	 */
	public void writeCode(String destination) {
		CompilationUnit unit = DaStGenASTBuilder.buildDaStGenAST(trees, conditions);
		CodeGenerator generator = new CodeGenerator(header, implementation);
		
		unit.applyVisitor(generator);
		
		// create the output files
		File destDir = FileUtilities.createDestinationDir(destination, runQuiet);
		FileUtilities.writeFile(destDir.getPath() +"/"+ unit.getName() + ".h", header.toString(), runQuiet);
		FileUtilities.writeFile(destDir.getPath() +"/"+ unit.getName() + ".cpp", implementation.toString(), runQuiet);
  }
}
