// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.DastGenAST;

public interface AbstractNodeContainer {

	public void addChildNodeFront(AbstractNode node);
	
	public void addChildNodeEnd(AbstractNode node);
	
}
